﻿this.CropTypeEnum =
{
    Standard: 0,
    Advanced: 1,
    Circle: 2
};