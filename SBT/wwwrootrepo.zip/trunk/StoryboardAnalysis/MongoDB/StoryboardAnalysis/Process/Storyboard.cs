﻿using MongoDB.Bson;
using StoryboardAnalysis.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoryboardAnalysis.DB
{
    class Storyboard :  StoryboardDB
    {
        // Image Function
        public async Task<bool> _AddMultipleStoryBoardImage(string JsonData)
        {
            return await AddMultipleRecord(JsonData, "storyboardimage");
        }
        public async Task<bool>  _AddStoryBoardImage( string JsonData )
        {
            return await AddOneRecord(JsonData, "storyboardimage");
        }
        public async Task<bool>  _RemoveStoryBoardImage( string JsonData )
        {
            return await RemoveRecords(JsonData, "storyboardimage");
        }
        public async Task<bool>  _UpdateStoryBoardImage(string JsonDataWhere , string JsonDataSet)
        {
            return await UpdateRecords(JsonDataWhere , JsonDataSet, "storyboardimage");
        }
        public List<BsonDocument> _FindStoryBoardImage(string JsonDataWhere, int nSkip = 0, int nLimit = 90000)
        {
            return FindRecord(JsonDataWhere, "storyboardimage" , nSkip , nLimit);
        }
        public bool _IsValidDataStoryBoardImage( BsonValue nImage )
        {
            return IsValidDataWithModel( nImage , _TableModels["storyboardimage"] );
        }

        public List<BsonDocument> _GetStoryboardImageUsageAll(int minStoryboardId,  ImageTypesEnum imageType)
        {
            return GetStoryboardImageUsageAll(minStoryboardId, "storyboardimage", imageType);
        }


        // Image Usage Function
        public async Task<bool>  AddMultipleStoryBoardImageUsage(string JsonData)
        {
            return await AddMultipleRecord(JsonData, "storyboardimageusage");
        }
        public async Task<bool>  AddStoryBoardImageUsage( string JsonData )
        {
            return await AddOneRecord(JsonData, "storyboardimageusage");
        }
        public async Task<bool>  RemoveStoryBoardImageUsage( string JsonData )
        {
            return await RemoveRecords(JsonData, "storyboardimageusage"); 
        }
        public async Task<bool>  UpdateStoryBoardImageUsage( string JsonDataWhere , string JsonDataSet  )
        {
            return await UpdateRecords(JsonDataWhere, JsonDataSet,  "storyboardimageusage");
        }
        public List<BsonDocument> FindStoryBoardImageUsage(string JsonDataWhere, int nSkip = 0, int nLimit = 90000)
        {
            return FindRecord(JsonDataWhere, "storyboardimageusage");
        }

    }
}
