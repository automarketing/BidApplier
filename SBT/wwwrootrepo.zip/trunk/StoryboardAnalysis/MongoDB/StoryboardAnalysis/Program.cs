﻿
using MongoDB.Bson;
using Newtonsoft.Json;
using StoryboardAnalysis.Dal;
using StoryboardAnalysis.DB;
using StoryboardAnalysis.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoryboardAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            StoryboardProcess S = new StoryboardProcess();

            string filename = ".//Data//storyboardimages.json";

            // Initial bulk insert
            //S.CheckAndAddMultipleStoryboardImage(-1 , File.ReadAllText(filename) );

            // Insert Test
            //S.CheckAndAddMultipleStoryboardImage(5009359, "[{ \"user_storyboard_image_id\":884951,\"user_storyboard_id\":500959,\"image_type_id\":4,\"int_foreign_key_id\":704,\"string_foreign_key_id\":\"\",\"image_count\":1}]" );

            // Select storyboard

            List<BsonDocument> resList = S.GetStoryboardImages(555274);

            //S.DeleteStoryboardImagesAsync(555274);

            // Remove with json
            // S.RemoveStoryBoardImage("{ \"user_storyboard_image_id\" : 1795958 }");

            // Update with json
            // S.UpdateStoryBoardImage("[{ \"user_storyboard_image_id\": 1795959 }]", "[{ \"image_type_id\": 55 },{ \"int_foreign_key_id\": 43 }]");

            resList = S.GetStoryboardsWithSpecificImage(4, 1228, 1, 10);

            resList = S.GetStoryboardImageUsageAll(1, ImageTypesEnum.PhotosForClass);
            Console.Out.WriteLine(resList.ToString());

            while (true)
            {
                Console.Out.WriteLine("here");
                System.Threading.Thread.Sleep(5000);
            }

        }
    }
}
