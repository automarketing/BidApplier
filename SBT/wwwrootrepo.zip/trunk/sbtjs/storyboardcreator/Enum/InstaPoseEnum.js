﻿this.InstaPoseEnum =
{
    Angry: 1,
    Speaking: 2,
    Explaining: 3,
    Sad: 4,
    Sleeping: 5,
    Complaining: 6,
    Holding : 7,
    Confusion: 8,
    Upset: 9,
    Sit: 10,
    Determined: 11,
    Happy: 12,
    Walking: 13,
    Shouting: 14,
    Scared: 15,

};