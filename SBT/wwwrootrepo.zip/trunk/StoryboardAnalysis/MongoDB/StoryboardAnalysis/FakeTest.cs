﻿using Newtonsoft.Json;
using StoryboardAnalysis.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoryboardAnalysis.Dal
{
    public static class FakeRepository
    {
        private static List<UserStoryboardImage> _StoryboardImages;
        public static List<UserStoryboardImage> StoryboardImages
        {
            get
            {
                if (_StoryboardImages == null)
                {
                    string filename = ".//Data//storyboardimages.json";
                    // Only use the seed cache if it is not older than configured age.


                    _StoryboardImages = JsonConvert.DeserializeObject<List<UserStoryboardImage>>(File.ReadAllText(filename));

                }
                return _StoryboardImages;
            }
        }

        #region "Basic Crud"
        public static List<UserStoryboardImage> GetStoryboardImages(int userStoryboardId)
        {
            return StoryboardImages.Where(x => x.user_storyboard_id == userStoryboardId).ToList();
        }

        public static void DeleteStoryboardImages(int userStoryboardId)
        {
            //handle case where we delete a storyboard from our records and want to remove analytics on it!
            IEnumerable<UserStoryboardImage> storyboardImages = GetStoryboardImages(userStoryboardId);

            foreach (UserStoryboardImage storyboardImage in storyboardImages)
            {
                StoryboardImages.Remove(storyboardImage);
            }
        }

        public static void AddStoryboardImages(int userStoryboardId, List<UserStoryboardImage> newStoryboardImages)
        {
            /*
             handle insert or update
             
              update
              * remove images that were in old version not in new version
              * update count of usage for images in both old/new versions
              * add new images
            
             insert
             * add everything
             
             */
            IEnumerable<UserStoryboardImage> currentStoryboardImages = GetStoryboardImages(userStoryboardId);

            foreach (UserStoryboardImage usi in currentStoryboardImages)
            {
                UserStoryboardImage newStoryboardImage = newStoryboardImages.Where(x => x.image_type_id == usi.image_type_id)
                    .Where(x => x.int_foreign_key_id == usi.int_foreign_key_id)
                    .Where(x => x.string_foreign_key_id == usi.string_foreign_key_id)
                    .FirstOrDefault();

                if (newStoryboardImage == null)
                {
                    StoryboardImages.Remove(usi);
                }
                else
                {
                    newStoryboardImages.Remove(newStoryboardImage);

                    if (newStoryboardImage.image_count == usi.image_count)
                        continue;

                    usi.image_count = newStoryboardImage.image_count;

                }
            }

            // await context.SaveChangesAsync(); //syntax for SQL!

            int i = 0;
            foreach (UserStoryboardImage usi in newStoryboardImages)
            {
                i++;
                StoryboardImages.Add(usi);

            }

            //await context.SaveChangesAsync();
        }

    

        #endregion

        #region "Reporting Features"

        public static IEnumerable<int> GetStoryboardsWithSpecificImage(int image_type_id, string foreign_key_id, int pageNumber, int pageSize)
        {

            return (from
                        usi in StoryboardImages
                    where
                        usi.image_type_id == image_type_id
                        && usi.string_foreign_key_id == foreign_key_id
                    orderby
                      usi.user_storyboard_image_id descending
                    select usi.user_storyboard_id)
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

        }
        public static IEnumerable<int> GetStoryboardsWithSpecificImage(int image_type_id, int foreign_key_id, int pageNumber, int pageSize)
        {

            return (from
                        usi in StoryboardImages
                    where
                        usi.image_type_id == image_type_id
                        && usi.int_foreign_key_id == foreign_key_id
                    orderby
                      usi.user_storyboard_image_id descending
                    select usi.user_storyboard_id)
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();
        }

        public static IEnumerable<UserStoryboardImageUsage> GetStoryboardImageUsageAll(int minStoryboardId, ImageTypesEnum imageType)
        {
            return
            StoryboardImages.Where(x => x.user_storyboard_id > minStoryboardId)
                            .Where(x => x.image_type_id == (int)imageType)
                            .GroupBy(x => new { x.image_type_id, x.int_foreign_key_id, x.string_foreign_key_id })

                            .Select(x => new UserStoryboardImageUsage
                            {
                                image_type_id = (int)imageType,
                                int_foreign_key_id = x.Key.int_foreign_key_id,
                                string_foreign_key_id = x.Key.string_foreign_key_id,
                                total_usage = x.Sum(y => y.image_count),
                                storyboards_using = x.Count()
                            })
                            .ToList();
                            
        }
        #endregion
    }
}

