﻿///  <reference path="../../SvgManip.js" />

function ColorableBox(color, colorScheme, title)
{
    this.Color = color;
    this.ColorScheme = colorScheme;
    this.ColorTitle = title;
}