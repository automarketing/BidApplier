﻿this.StoryboardPartTypeEnum =
       {
           StoryboardCell: 1,
           StoryboardCellTitle: 2,
           StoryboardCellDescription: 3,

           StoryboardAreaTitle: 4,
           StoryboardCellOuterBox: 5,
           StoryboardAttributionArea:6
       };
