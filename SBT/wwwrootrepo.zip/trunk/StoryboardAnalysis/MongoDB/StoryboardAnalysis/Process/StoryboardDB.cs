﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using System.Security.Authentication;
using Newtonsoft.Json;
using System.Dynamic;
using System.IO;
using Newtonsoft.Json.Linq;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using StoryboardAnalysis.Models;

namespace StoryboardAnalysis.DB
{
    class StoryboardDB
    {
        public SortedDictionary<string, BsonValue> _TableModels = new SortedDictionary<string, BsonValue>();

        private MongoClient mongoClient;
        private IMongoDatabase mongoDB; 
        public StoryboardDB()
        {
            _ConnectDatabase();
            _LoadModelsAsync();
        }

        private void _ConnectDatabase()
        {
            string connectionString = @"mongodb://192.168.137.36";
            MongoClientSettings settings = MongoClientSettings.FromUrl(
                new MongoUrl(connectionString)
            );
            mongoClient = new MongoClient(settings);
            mongoClient.ListDatabases();
            mongoDB = mongoClient.GetDatabase("storyboard");
            Console.Out.WriteLine("Database is connected");

        }

        private void _LoadModelsAsync()
        {
            var collectionTableModel = mongoDB.GetCollection<BsonDocument>("tablemodel");
            List<BsonDocument> bDocList = collectionTableModel.Find(Builders<BsonDocument>.Filter.Empty).ToList();
            foreach (BsonDocument bDoc in bDocList)
            { 
                _TableModels[bDoc.GetElement("tablename").Value.ToString()] = bDoc.GetElement("scheme").Value;
            }
            Console.Out.WriteLine("Table Model is loaded successfully");
        }



        public override bool Equals(object obj)
        {
            var board = obj as StoryboardDB;
            return board != null &&
                   EqualityComparer<MongoClient>.Default.Equals(mongoClient, board.mongoClient);
        }

        private bool hasProperty(BsonValue Prop, BsonValue ModelField)
        { 
            return !Prop[ModelField["field"].ToString()].IsBsonNull;
        }

        public bool IsValidDataWithModel(BsonValue bData, BsonValue model)
        {
            foreach (BsonValue item in (BsonArray)model)
            {
                if (!hasProperty( bData, item ))
                    return false;
            }
            return true;
        }

        /// <summary>
        /// 
        ///  Add Json Data
        ///  Scheme By TableModel
        ///  
        /// </summary>
        /// <param name="JsonData"></param>
        /// <param name="TableName"></param>
        /// <returns>Insert Result</returns>
        /// pDos 2017/09/22

        public async Task<bool> AddOneRecord(string JsonData , string TableName )
        {
            BsonValue B = BsonSerializer.Deserialize<BsonValue>(JsonData);

            if (!IsValidDataWithModel(B, _TableModels[TableName]))
                return false;

            await mongoDB.GetCollection<BsonDocument>(TableName).InsertOneAsync(B.ToBsonDocument());
            return true;
        }


        public async Task<bool> AddMultipleRecord(string JsonData, string TableName)
        {
            BsonArray B = BsonSerializer.Deserialize<BsonArray>(JsonData);
            List<BsonDocument> validList = new List<BsonDocument>();
            bool resFlag = false;

            foreach (BsonValue item in B)
            {
                if (IsValidDataWithModel(item, _TableModels[TableName]))
                {
                    validList.Add(item.ToBsonDocument());
                    resFlag = true;
                }
            }
            await mongoDB.GetCollection<BsonDocument>(TableName).InsertManyAsync(validList);
            return resFlag;
        }

        private FilterDefinition<BsonDocument> GetFilterDefinition(string JsonWhere)
        {
            BsonArray BWhere = BsonSerializer.Deserialize<BsonArray>(JsonWhere);

            FilterDefinition<BsonDocument> filter = null;

            foreach (BsonValue bW in BWhere)
            {
                if (filter == null)
                     filter = Builders<BsonDocument>.Filter.Eq(bW.AsBsonDocument.GetElement(0).Name.ToString(), bW.AsBsonDocument.GetElement(0).Value.ToInt32());
                else filter = filter & Builders<BsonDocument>.Filter.Eq(bW.AsBsonDocument.GetElement(0).Name.ToString(), bW.AsBsonDocument.GetElement(0).Value.ToInt32());
            }
            return filter;
        }


        private UpdateDefinition<BsonDocument> GetUpdateDefinition(string JsonSet)
        {
            BsonArray BSet = BsonSerializer.Deserialize<BsonArray>(JsonSet);

            UpdateDefinition<BsonDocument> update = null;

            foreach (BsonValue bS in BSet)
            {
                if (update == null)
                     update = Builders<BsonDocument>.Update.Set(bS.AsBsonDocument.GetElement(0).Name.ToString(), bS.AsBsonDocument.GetElement(0).Value.ToString());
                else update = update.Set(bS.AsBsonDocument.GetElement(0).Name.ToString(), bS.AsBsonDocument.GetElement(0).Value);
            }

            return update;
        }
        /// <summary>
        /// 
        ///  Remove Record with Filter Json Data
        ///  Scheme By TableModel
        ///  
        /// </summary>
        /// <param name="JsonData"></param>
        /// <param name="TableName"></param>
        /// <returns>Remove Result</returns>
        /// pDos 2017/09/21

        public async Task<bool> RemoveRecords(string JsonWhere, string TableName )
        {
            FilterDefinition<BsonDocument> filter = GetFilterDefinition(JsonWhere);

            await mongoDB.GetCollection<BsonDocument>(TableName).DeleteManyAsync(filter);
            return true;
        }

        /// <summary>
        /// 
        ///  Update Record with Filter and Set Json data
        ///  Scheme By TableModel
        ///  
        /// </summary>
        /// <param name="JsonWhere"></param>
        /// <param name="JsonSet"></param>
        /// <param name="TableName"></param>
        /// <returns>Update Result</returns>
        /// pDos 2017/09/21

        public async Task<bool> UpdateRecords( string JsonWhere, string JsonSet,  string TableName )
        {
            FilterDefinition<BsonDocument> filter = GetFilterDefinition(JsonWhere);
            UpdateDefinition<BsonDocument> update = GetUpdateDefinition(JsonSet); 

            await mongoDB.GetCollection<BsonDocument>(TableName).UpdateManyAsync(filter, update);
            return true;
        }


        /// <summary>
        /// 
        ///  Remove Json Data
        ///  Scheme By TableModel
        ///  
        /// </summary>
        /// <param name="JsonWhere"></param>
        /// <param name="JsonSet"></param>
        /// <param name="TableName"></param>
        /// <returns>Update Result</returns>
        /// pDos 2017/09/21

        public List<BsonDocument> FindRecord(string JsonWhere, string TableName , int nSkip = 0 , int nLimit = 90000)
        {
            FilterDefinition<BsonDocument> filter = GetFilterDefinition(JsonWhere);
            List<BsonDocument> resList = mongoDB.GetCollection<BsonDocument>(TableName).Find(filter).Skip(nSkip).Limit(nLimit).ToList<BsonDocument>();

            return resList;
        }


        /// <summary>
        /// 
        ///  GetStoryboardImageUsageAll
        ///  Scheme By TableModel
        ///  
        /// </summary>
        /// <param name="minStoryboardId"></param>
        /// <param name="TableName"></param>
        /// <param name="imageType"></param>
        /// <returns>List<BsonDocument></BsonDocument></returns>
        /// pDos 2017/10/05

        public List<BsonDocument> GetStoryboardImageUsageAll(int minStoryboardId, string TableName, ImageTypesEnum imageType)
        {
            var match = new BsonDocument
                            {
                                {"image_type_id", (int)imageType},
                                {"user_storyboard_id", new BsonDocument
                                    {
                                        {
                                            "$gte", minStoryboardId
                                        }
                                    }
                                }
                            };
            var group = new BsonDocument
                            {
                                { "_id", new BsonDocument
                                    {
                                        { "image_type_id","$image_type_id" },
                                        { "int_foreign_key_id","$int_foreign_key_id" },
                                        { "string_foreign_key_id","$string_foreign_key_id" }
                                    }
                                },
                                { "image_type_id",   new BsonDocument { { "$first", "$image_type_id" } } } ,
                                { "int_foreign_key_id",   new BsonDocument { { "$first", "$int_foreign_key_id" } } } ,
                                { "string_foreign_key_id",   new BsonDocument { { "$first", "$string_foreign_key_id" } } } ,
                                { "storyboards_using", new BsonDocument
                                    {
                                        { "$sum", 1 } 
                                    }
                                } ,
                                {
                                    "total_usage", new BsonDocument
                                    {
                                        { "$sum", "$image_count" }
                                    }
                                }
                            } ;
            PipelineDefinition<BsonDocument , BsonDocument > pipeline = new[] { match  };
            return mongoDB.GetCollection<BsonDocument>(TableName).Aggregate().Match( match ).Group( group) .ToList();
              
        }

    }
}