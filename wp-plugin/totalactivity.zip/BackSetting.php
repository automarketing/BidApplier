<?php
// User setting page for User activity plugin
		global $wpdb;

		if( isset($_POST['keep_period']) )
		{
			print_r($_POST);
			$wpdb->update( "wp_useracitivity_opt" , array( "value"=>$_POST['keep_period']  ) , array("option" => "keep_period" ) );
			$wpdb->update( "wp_useracitivity_opt" , array( "value" =>$_POST['display_limit']) , array("option" => "display_limit" ));
			$wpdb->delete( 'wp_useracitivity_opt' , array( 'option' => 'fpattern' ) );

			if( isset($_POST['fpattern']) )
				foreach ( $_POST['fpattern'] as $sItem ) 
					$wpdb->insert('wp_useracitivity_opt' , array('option' => 'fpattern' , 'value' => $sItem ) ); 

		}
		else $_POST['keep_period'] = $wpdb->get_var( "select value from wp_useracitivity_opt where option='keep_period'" );

	 

		$patternList = $wpdb->get_results( "select value from wp_useracitivity_opt where option='fpattern'", 'ARRAY_A' );
		$display_limit = $wpdb->get_var( "select value from wp_useracitivity_opt where option='display_limit'" );



		$plugin_url = plugin_dir_url( __FILE__ );

?>
	
	<br> 
	<h2 class="nav-tab-wrapper">
		<a href="#" id='visit_activity' class="nav-tab nav-tab-active" onclick='set_tab_nav(this.id);'>
			Visit Activity
		</a>
		<a href="#" id='crm_activity' class="nav-tab "  onclick='set_tab_nav(this.id);'>
			CRM Integration
		</a>
        </h2>
       	
        
	<br><br>
		<form method="post" onsubmit="selectAllOptions();">
			<div style='width:400px; ' align='right'>
			<input type='submit' value=' Save ' class='generalBtn' >
			</div>

			<div id='visit_activity_div' >
				<table>
					<tr>
					<td>
						<label for="keep_period">Keep history &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
					</td>
					<td>
						<select id='keep_period' name='keep_period' style='width:150px;'>
							<option value='1' <?php selected($x == 1) ?> >1 day</option>
							<option value='5' <?php selected($x == 5) ?>>5 day</option>
							<option value='30' <?php selected($x == 30) ?>>30 day</option>
							<option value='10000' <?php selected($x == 10000) ?>>forever</option>
						</select> 
					</td>
					</tr>
					<tr>
					<td>
						<label for="keep_period">Display Row limit &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
					</td>
					<td>
						<input type='input' name='display_limit' style='width:150px;' value='<?php echo $display_limit; ?>'>
					</td>
					</tr>
				</table>

				<br><br>
				<div class="factory-separator"></div>
				<br><br>
				Exclude Filter Pattern &nbsp;&nbsp;&nbsp;&nbsp;<br><br>
				<input type='input' id='filterURI' name='filterURI' style='width:300px;'>&nbsp;&nbsp;&nbsp;&nbsp;
				<input type='button' value='Add' onclick='add_pattern();'>
				<input type='button' value='Remove'  onclick='remove_pattern();' >
				<br>
				<br>
				<br>
				<select name="fpattern[]" id="fpattern" MULTIPLE style='width:450px; height:400px;'>
					<?php
						for( $i = 0 ; $i < count($patternList) ; $i++ )
						{
							echo "<option value='".$patternList[$i]['value']."'>".$patternList[$i]['value']."</option>";
						}
					?>
				</select>

			</div>

			<div id='crm_integration_div' style='display:none'>
				<label for="crm">Integrate with CRM </label>
				<select id='crm' onchange="check_crm();">
					<option value=1>ON</option>
					<option value=0>OFF</option>
				</select> 

				<br><br>
				<div class="factory-separator"></div>
				<br><br>

				 
				<div id="crm_div">
					<input type='hidden' id='crm_val'>
					<div id="undefined" class="dd-container" style="width: 450px;">
						<div id='selected_crm' class="dd-select" style="width: 450px; background: rgb(238, 238, 238);" > 
							<a class="dd-selected" onclick='toggle_menu();'>
							<label class="dd-selected-text">None</label>
							<small class="dd-selected-description dd-desc dd-selected-description-truncated">Emails of subscribers will be saved in the WP database.</small></a>
							<span id='dd_select_pointer' class="dd-pointer dd-pointer-down "></span>
						</div>

						<ul id='viewdiv_crm' class="dd-options dd-click-off-close" style="width: 450px; display: none;">
							<li id='fcont0'>
								<a class="dd-option" onclick="check_crm_type('Z','fcont0');">  
								<img class="dd-option-image dd-image-right" src="<?php echo $plugin_url; ?>/image/salesforce.png"> 
								<label class="dd-option-text">Zoho CRM</label> 
								<small class="dd-option-description dd-desc">online customer relationship management software for managing your sales, marketing & support in a single system</small></a>
							</li >
							<li  id='fcont1'>
								<a class="dd-option" onclick="check_crm_type('S','fcont1');">  
								<img class="dd-option-image dd-image-right" src="<?php echo $plugin_url; ?>/image/zoho.png"> 
								<label class="dd-option-text">Salesforce CRM</label> 
								<small class="dd-option-description dd-desc">Customer Success Platform</small></a>
							</li>
							<li  id='fcont2'>
								<a class="dd-option" onclick="check_crm_type('F','fcont2');">  
								<label class="dd-option-text">For others </label> 
								<small class="dd-option-description dd-desc">contact us on : contact@silicontern.com</small></a>
							</li>
						</ul>
					</div>
					<br><br><br>

					<div id='ZS_box' style='display:none' >
						<table>
							<tr>
								<td>
									Username : 
								</td>
								<td>
									<input type='crm_username'>
								</td>
						 	</tr>
						 	<tr>
								<td>
									Password : 
								</td>
								<td>
									<input type='crm_password'>
								</td>
						 	</tr>
						 	<tr>
								<td>
									URL : 
								</td>
								<td>
									<input type='crm_username'>
								</td>
						 	</tr> 
						</table>
					</div>

					<div id='F_box'  style='display:none'>
						Topic: <input type='input' style='width:450px;'> <br><br>
						Email Text:<br><br>
						<textarea id='email_cont' rows="30" cols="50" style='width:490px; height:450px;'></textarea>
						</br>
						</br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Send Mail' >
					</div>

					<br>
				</div>
			</div>


			

			<script> 
				function check_crm()
				{
					if( document.getElementById("crm").value == 0 ) document.getElementById("crm_div").style.display='none';
					if( document.getElementById("crm").value == 1 ) document.getElementById("crm_div").style.display='';
				}

				function check_crm_type(val , id)
				{
					document.getElementById("crm_val").value = val;

					if( val == 'Z' || val == 'S' ) 
					{
						document.getElementById("ZS_box").style.display = '';
						document.getElementById("F_box").style.display = 'none';
					}

					if( val == 'F' )
					{
						document.getElementById("ZS_box").style.display = 'none';
						document.getElementById("F_box").style.display = '';
					}
					selected_crm.innerHTML = document.getElementById(id).innerHTML;
					selected_crm.innerHTML += "<span id='dd_select_pointer' class='dd-pointer dd-pointer-down'></span>";
					toggle_menu();

				}
				function set_tab_nav(  id )
		        	{
		        		if( id == 'visit_activity' )
		        		{
		        			document.getElementById('crm_activity').className = "nav-tab";
		        			document.getElementById('visit_activity').className = "nav-tab nav-tab-active";
		        			visit_activity_div.style.display='';
		        			crm_integration_div.style.display='none';

		        		}

		        		if( id == 'crm_activity' )
		        		{
		        			document.getElementById('crm_activity').className = "nav-tab nav-tab-active";
		        			document.getElementById('visit_activity').className = "nav-tab"; 
		        			visit_activity_div.style.display='none';
		        			crm_integration_div.style.display='';
		        		}
		        	} 

		        	function toggle_menu()
				{ 
					if( viewdiv_crm.style.display == 'block' )
					{ 
						viewdiv_crm.style.display = 'none';
						dd_select_pointer.className = "dd-pointer dd-pointer-down";

					}
					else
					{
						viewdiv_crm.style.display = 'block';
						dd_select_pointer.className = "dd-pointer dd-pointer-up";
						
					}
				}

				function add_pattern()
				{

					var nF = filterURI.value;
					if( nF == '' ) return;
					var opt = document.createElement('option');
					opt.value = nF;
    					opt.innerHTML = nF;
    					fpattern.appendChild(opt);
    					filterURI.value = '';
				}

				function remove_pattern()
				{ 
					fpattern.remove(fpattern.selectedIndex);
				}

				function selectAllOptions() 
				{
					var obj = fpattern; 
					for (var i=0; i<fpattern.options.length; i++) {
					    	fpattern.options[i].selected = true;
					    }
				}

			</script>

			
		</form>

<?php