﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoryboardAnalysis.Models
{
    public enum ImageTypesEnum
    {
        UploadedItem = 1,
        SearchSBTContent = 2,
        CoreContent = 4,
        PhotosForClass = 5,
    }
}
