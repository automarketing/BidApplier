﻿function Vector(x1,y1,x2,y2)
{
    this.X1 = x1;
    this.Y1 = y1;

    this.X2 = x2;
    this.Y2 = y2;
}