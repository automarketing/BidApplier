/*
    pDos 2017.10.5
*/

var localDB = {
    init: function () {
        
        this.initDatabase();
    },

    initDatabase: function() {
        try {
            if (!window.openDatabase) {
                alert('Local Databases are not supported by your browser. Please use a Webkit browser for this demo');
            } else {
                var shortName = 'StoryboardDB',
                    version = '1.0',
                    displayName = 'Storyboard Database',
                    maxSize = 1024*1024*50; // 50 MegaByte
                    
                db = openDatabase(shortName, version, displayName, maxSize);
                this.createTables();
            }
        } catch(e) {
            if (e === 2) {
                // Version mismatch.
                console.log("Invalid database version.");
            } else {
                console.log("Unknown error "+ e +".");
            }
            return;
        } 
    },
    
    /***
    **** CREATE TABLE ** 
    ***/
    createTables: function() {
        var that = this;
        db.transaction(
            function (transaction) {
                transaction.executeSql('CREATE TABLE IF NOT EXISTS storyboard(id INTEGER NOT NULL PRIMARY KEY, storyboard_name TEXT, content TEXT );', [], that.nullDataHandler, that.errorHandler);
            }
        ); 		
    },

    
    /***
    **** UPDATE TABLE ** 
    ***/
    Save: function( storyboard_name , content ) {
        db.transaction(
            function (transaction) { 
                transaction.executeSql( "Delete from storyboard" );
                transaction.executeSql( "INSERT INTO storyboard(storyboard_name , content) values(? , ?) ", [storyboard_name, content] );
            }
        );
    },
    
    Load: function( post_func ) {
        var that = this;
        db.transaction(
            function (transaction) {
                transaction.executeSql("SELECT * FROM storyboard;", [] , function( transaction, results ) {
                        // Handle the results
                        var i=0,
                            row;
                        if( results.rows.length > 0 )
                        {
                            post_func( results.rows.item(0).storyboard_name , results.rows.item(0).content );
                        }
                    }
                , that.errorHandler);
            }
        );	
    },
        
    errorHandler: function( transaction, error ) {
    
        if (error.code===1){
            // DB Table already exists
        } else {
            // Error is a human-readable string.
            console.log('Oops.  Error was '+error.message+' (Code '+ error.code +')');
        }
        return false;		    
    },
    
    nullDataHandler: function() {
        console.log("SQL Query Succeeded");
    },
        
    /***
    **** DELETE DB TABLE ** 
    ***/
    dropTables: function() {
        var that = this;
        db.transaction(
            function (transaction) {
                transaction.executeSql("DROP TABLE page_settings;", [], that.nullDataHandler, that.errorHandler);
            }
        );
        console.log("Table 'page_settings' has been dropped.");
        //location.reload();			
    } 
};

//Instantiate Demo
localDB.init();

self.addEventListener('message', function(e) {
	var data = e.data;
	switch (data.cmd) {
	  case 'Save':
		localDB.Save( data.storyboard_name , data.content );
		self.postMessage( { 'cmd' : 'Save' } );
		break;
	  case 'Load':
	  	localDB.Load( function( storyboard_name , content ){
			  self.postMessage( { 'cmd' : 'Load' , 'storyboard_name' : storyboard_name , 'content' : content } )
		});
		break;
	  default: 
	};
  }, false);

