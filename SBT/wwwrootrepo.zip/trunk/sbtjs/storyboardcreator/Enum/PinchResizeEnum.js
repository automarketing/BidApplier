﻿PinchResizeEnum =
    {
        Proportional: 1,
        Vertical: 2,
        Horizontal: 3
    };