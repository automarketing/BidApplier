﻿/// <reference path="../svgManip.js" />

function TextStateData()
{
    this.Text = "";
    this.DefaultText = "";

    //this.Font = "nobile regular";
    this.Font = MyBrowserProperties.Public_GetDefaultFont();
    this.FontSize = "10";
    this.FontColor = "000000";
    this.TextAlignment = "middle";

    this.Textable = false;
    this.TextOffsetLeft = 0;
    this.TextOffsetRight = 0;
    this.TextOffsetTop = 0;

    this.Private_IdTextableRectangle = "";
    this.Private_RevertColor = "";

    this.RemovalId = null;

    this._QuillDeltas = null;
}

function TextState(id)
{
    var initData = new TextStateData();
    this.Private_ShapeId = id;
    this.D = new Array();
    this.D.push(initData); // initialy one data push
    this.CurrentId = 0;
    this.Private_CheckForMetaData(id);
}

TextState.prototype.Public_ClearDefaults = function ()
{
    // operate on only currentId
    if (this.D[ this.CurrentId ].Text != this.D[ this.CurrentId ].DefaultText)
        return false;

    if (UseSummerNote)
    {
        SbtSummerNoteHelper.ResetToDefaults();
        this.Public_SetQuillDeltas(SbtSummerNoteHelper.GetDeltas());
    }
    
    this.D[ this.CurrentId ].Text = "";
    return true;

};

TextState.prototype.Public_GetSavedFontColor = function ()
{
    if ( this.D[ this.CurrentId ].Private_RevertColor != "" )
        return this.D[ this.CurrentId ].Private_RevertColor;

    return this.D[ this.CurrentId ].FontColor;
};

TextState.prototype.Public_SetFontColor = function (color, isPreview)
{
    if (this.D[this.CurrentId].Private_RevertColor === "")
    {
        this.D[this.CurrentId].Private_RevertColor = this.D[this.CurrentId].FontColor;
    }

    if (isPreview === false)
    {
        this.D[this.CurrentId].Private_RevertColor = color;
    }

    this.D[this.CurrentId].FontColor = color;
};

TextState.prototype.Public_ResetFontColor = function ()
{
    if (this.D[this.CurrentId].Private_RevertColor != null && this.D[this.CurrentId].Private_RevertColor != "")
    {
        this.D[this.CurrentId].FontColor = this.D[this.CurrentId].Private_RevertColor;
    }
};


TextState.prototype.Public_GenerateQuillForOneLiner = function (text, fontSize, textAlignment, font, fontColor)
{
    this.Public_SetQuillDeltas(SbtSummerNoteHelper.GenerateQuillForOneLiner(text, fontSize, textAlignment, font, fontColor));
};

TextState.prototype.Public_ConvertToQuill = function ()
{
    //"", right, center
    var alignment = "";
    if (this.D[this.CurrentId].TextAlignment == "middle")
        alignment = "center";
    else if (this.D[this.CurrentId].TextAlignment == "end")
        alignment = "right";

    var color = this.D[this.CurrentId].FontColor === "" ? "black" : this.D[this.CurrentId].FontColor;

    if (UseSummerNote)
    {
        try
        {
            //var t0 = performance.now();
        alignment = alignment == "" ? "left" : alignment;
        SbtSummerNoteHelper.ResetToDefaults();
        
        var pTag = "<p style=\"text-align:" + alignment + "; color:" + color + ";font-family: " + this.D[this.CurrentId].Font.replaceAll2("\"", "\'") + "; font-size:" + this.D[this.CurrentId].FontSize + "pt;\">";


        var toParseText = this.D[this.CurrentId].Text
            .replaceAll2("\n\n\n", "\n\n")
            .replaceAll2("\n", "</p>" + pTag);

        toParseText = pTag + toParseText + "</p>";

      

        SbtSummerNoteHelper.UpdateForHtml(toParseText);

     
        this.Public_SetQuillDeltas(SbtSummerNoteHelper.GetDeltas());

        if (this.Public_GetQuillDeltas() == null)
        {
            try
            {
                LogErrorMessage("Post Conversion - Quill is NULL - " + this.D[this.CurrentId].Text);
            } catch (e2)
            {
                LogErrorMessage("Post Conversion - Quill is NULL - ERROR",e2);
            }
            
        }
        SbtSummerNoteHelper.ResetToDefaults();
        } catch (e)
        {
            try
            {
                LogErrorMessage("Public_ConvertToQuill Text " + this.D[this.CurrentId].Text, e)
            } catch (e2)
            {
                LogErrorMessage("Public_ConvertToQuill Error Fallback", e2)
            }
        }
    }
};

TextState.prototype.Public_GetTextArea = function (bbox, scaleX, scaleY, offsetX, offsetY, isSpringable)//, flipX, flipY)
{
    var dimensions = new Object();

    if (this.D[this.CurrentId].Private_IdTextableRectangle != null && this.D[this.CurrentId].Private_IdTextableRectangle.length > 0)
    {
        var textableRectangle = $("#" + this.D[this.CurrentId].Private_IdTextableRectangle);
        var x = Number(textableRectangle.attr("x"));
        var y = Number(textableRectangle.attr("y"));
        var width = Number(textableRectangle.attr("width"));
        var height = Number(textableRectangle.attr("height"));


        dimensions.Left = (x - offsetX) * scaleX;
        dimensions.Width = width * scaleX;
        dimensions.Top = (y - offsetY) * scaleY;
        dimensions.Height = height * scaleY;

        if (isSpringable)
        {
            //extra complex for ie10/11 :( abs 6/22/16
            var textRect = GetGlobalById(this.D[this.CurrentId].Private_IdTextableRectangle);
            var parentId = $(textRect).parent().attr("id")

            var transform = SvgCreator.GetTransform(parentId);

            dimensions.Width *= transform.Scale[0]; 

            dimensions.Height *= transform.Scale[1]; 

        }
 
    }
    else
    {
        var width = bbox.width;
        var height = bbox.height;

        dimensions.Left = width * this.D[this.CurrentId].TextOffsetLeft;

        dimensions.Top = (height * this.D[this.CurrentId].TextOffsetTop);
        dimensions.Width = (width * this.D[this.CurrentId].TextOffsetRight) - dimensions.Left;
        dimensions.Height = Infinity;
    }



    return dimensions;
};

TextState.prototype.Public_SetQuillDeltas = function (quillDeltas, supressWarning)
{
    // var stack = new Error().stack;
    // console.log("TextState.prototype.Public_SetQuillDeltas",SbtLib.DeepCopy(quillDeltas));
    // console.log( stack );
 

    this.D[this.CurrentId]._QuillDeltas = SbtLib.DeepCopy(quillDeltas); 
 
    try
    {
        if(supressWarning==null || supressWarning==false)
        if (this.D[this.CurrentId]._QuillDeltas == null)
        {

            if (quillDeltas == null)
            {
                LogErrorMessage("_Quill deltas is null, and quilldeltas was null")
            }
            else
                LogErrorMessage("_Quill deltas is null, and quilldeltas was NOT null", { message: "quillDeltas: " + JSON.stringify(quillDeltas), stack: "" });

        }
    } catch (e)
    {
        LogErrorMessage("Public_SetQuillDeltas - errors", e)

    }
    
}

TextState.prototype.Public_GetQuillDeltas = function ()
{ 
    return this.D[this.CurrentId]._QuillDeltas;
}

TextState.prototype.Public_SummerNote_SetFontSizeAndColor = function (size, color)
{
    var deltas = SbtSummerNoteHelper.Deltas_UpdateFontSizeAndColor(this.Public_GetQuillDeltas(), size, color);
    this.Public_SetQuillDeltas(deltas);

    if (deltas == null)
    {
        LogErrorMessage("SbtSummerNoteHelper.OnChange: Deltas null ");
    }
}


TextState.prototype.Public_QuillSetFontColor = function (color)
{
    quill.setContents ( this.Public_GetQuillDeltas());
    quill.formatText(0, 1000, 'color', color)

    this.Public_SetQuillDeltas(quill.getContents().ops);

 
}

TextState.prototype.Public_QuillSetFontSize = function (size)
{
    quill.setContents (this.Public_GetQuillDeltas());
    quill.formatText(0, 1000, 'size', size.toString());

    //not always needed, but helps with making sure you are editing the right version of the data
    this.Public_SetQuillDeltas(quill.getContents().ops);
}

TextState.prototype.Public_GetFontStyles = function ()
{
    var styles = new Object();

    styles.Text = this.D[this.CurrentId].Text;
    styles.DefaultText = this.D[this.CurrentId].DefaultText;

    styles.Font = this.D[this.CurrentId].Font;
    styles.FontSize = this.D[this.CurrentId].FontSize;
    styles.FontColor = this.D[this.CurrentId].FontColor;
    styles.TextAlignment = this.D[this.CurrentId].TextAlignment;

    styles.Textable = this.D[this.CurrentId].Textable;
    styles._QuillDeltas = SbtLib.DeepCopy(this.D[this.CurrentId]._QuillDeltas);

    return styles;
};

//copies text and font
TextState.prototype.CopyFontStyles = function (TD)
{ 
    this.D[this.CurrentId].Text = TD.Text;
    this.D[this.CurrentId].DefaultText = TD.DefaultText;

    this.D[this.CurrentId].Font = this.UpdateOldFont(TD.Font);
    this.D[this.CurrentId].FontSize = TD.FontSize;
    this.D[this.CurrentId].FontColor = TD.FontColor;
    this.D[this.CurrentId].TextAlignment = TD.TextAlignment;
    this.D[this.CurrentId].Textable = TD.Textable;

    //if something is already corrupt, this won't help, but partial check.  Soome data from 5/13/17 to 5/15/17 may be corrupted...  as well as any copy of a textable?'
    if (this.D[this.CurrentId].Text != null && this.D[this.CurrentId].Text != "")
        this.D[this.CurrentId].Textable = true;
    

   
    if (UseQuill || UseSummerNote)
    {
        // var stack = new Error().stack;
        // console.log("TextState.prototype.CopyFontStyles ",TD._QuillDeltas);
        // console.log( stack );

        this.D[this.CurrentId]._QuillDeltas = TD._QuillDeltas;
     

        if (this.D[this.CurrentId]._QuillDeltas == null && TD.Textable==true)
        {
            this.Public_ConvertToQuill();
        }

    }

     
};

TextState.prototype.Copy = function (textState)
{
    var i;
    for( i = 0 ;  i < textState.D.length; i++ )
    {
        if( this.D.length < i+1 )
        {
            var eData = new TextStateData();
            this.D.push( eData );
        }
        this.CurrentId = i;
        this.CopyFontStyles(textState.D[i]);
        this.D[this.CurrentId].Textable = textState.D[i].Textable;
        this.D[this.CurrentId].TextOffsetLeft = textState.D[i].TextOffsetLeft;
        this.D[this.CurrentId].TextOffsetRight = textState.D[i].TextOffsetRight;
        this.D[this.CurrentId].TextOffsetTop = textState.D[i].TextOffsetTop;
    
        if (textState.D[i].Private_IdTextableRectangle != null && textState.D[i].Private_IdTextableRectangle.length > 0)
        {
        
            this.D[this.CurrentId].Private_IdTextableRectangle = this.Private_ShapeId + "_TextBoxArea"+i;
            var shape = $("#" + this.Private_ShapeId);
            var textRectangle = shape.find("[id=" + textState.D[i].Private_IdTextableRectangle + "]");
            textRectangle.attr("id", this.D[this.CurrentId].Private_IdTextableRectangle);
        }
        this.D[this.CurrentId].RemovalId = textState.D[i].RemovalId;
    }
    this.CurrentId = textState.CurrentId;
    

};

TextState.prototype.UpdateOldFont = function (font)
{
    try
    {
        var fontLowerCase = font.toLowerCase();

        if (fontLowerCase.indexOf("arial") >= 0)
            return "Roboto";

        if (fontLowerCase.indexOf("calibri") >= 0)
            return "Roboto";

        if (fontLowerCase.indexOf("courier") >= 0)
            return "Roboto";

        if (fontLowerCase.indexOf("junction") >= 0)
            return "'Montserrat Alternates'";

        if (fontLowerCase.indexOf("gothic") >= 0)
            return "'Francois One'";

        if (fontLowerCase.indexOf("linden") >= 0)
            return "'times new roman'";

        if (fontLowerCase.indexOf("nobile") >= 0)
            return "'Montserrat Alternates'";

        if (fontLowerCase.indexOf("goudy") >= 0)
            return "Coustard";

        if (fontLowerCase.indexOf("aleo") >= 0)
            return "Coustard";

        if (fontLowerCase.indexOf("questrial") >= 0)
            return "'Montserrat Alternates'";

        if (fontLowerCase.indexOf("green fuz") >= 0)
            return "Creepster";

        if (fontLowerCase.indexOf("times new roman") >= 0)
            return "Lora";

        if (fontLowerCase.indexOf("david") >= 0)
            return "'Varela Round'";

    } catch (e)
    {
        LogErrorMessage("TextState.UpdateFont", e);
    }

    return font;
};

TextState.prototype.Private_CheckForMetaData = function (id)
{ 
    // pDos
    // This codepart is not sure , I need to check with many real data
    var md = $("#" + id).find("sbtdata");
    if (md.length == 0)
        return;

    var textOffsetData = md.find("textoffset");
    if (textOffsetData.length > 0)
    {
        this.Private_HandleOldTextables(textOffsetData);
    }

    var textable = md.find("textable");
    if (textable.length > 0)
    {
        this.Private_HandleTextable(textable);
    }
 
    this.Private_CheckForRemovals(md);

    //md.remove();
};

TextState.prototype.Private_HandleTextable = function (textOffsetData)
{
    // handle first data 
    this.D[0].Textable = true;
    var shape = $("#" + this.Private_ShapeId );
 
 
    for(var i = 0 ; i < textOffsetData.length ; i++ )
    {
        if( !this.D[i] )
        {
            this.D[i] = new TextStateData();

        }
        this.D[i].Private_IdTextableRectangle = textOffsetData[i].getAttribute("textarea");
        var textRectangle = shape.find("[id=" + this.D[i].Private_IdTextableRectangle + "]");
        if (textRectangle != null)
        {
            this.D[i].Private_IdTextableRectangle = this.Private_ShapeId + "_TextBoxArea"+i;
            textRectangle.attr("id", this.D[i].Private_IdTextableRectangle); 
        }
    }
};

TextState.prototype.Private_HandleOldTextables = function (textOffsetData)
{
    this.D[this.CurrentId].Textable = true;
    this.D[this.CurrentId].TextOffsetLeft = textOffsetData.find("left").first().text();
    this.D[this.CurrentId].TextOffsetRight = textOffsetData.find("right").first().text();
    this.D[this.CurrentId].TextOffsetTop = textOffsetData.find("top").first().text();
};

TextState.prototype.Private_CheckForRemovals = function (md)
{
    var removal = md.find("removetext");
    if (removal.length == 0)
        return;

    this.D[this.CurrentId].RemovalId = removal.first().text();    //why does firefox require thsi???!!?

};