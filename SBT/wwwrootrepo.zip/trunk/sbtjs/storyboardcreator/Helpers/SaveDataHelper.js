﻿var SaveDataHelper = function ( isLocalDB )
{
    var SaveDataHelperObject = new Object();

    SaveDataHelperObject.NewStoryboard = 1;
    SaveDataHelperObject.EditStoryboard = 2;
    SaveDataHelperObject.AutoSave = 3;

    function putGlobalCellCropRatioToCell(){
        var i,  j;
        for( i = 0 ; i < StoryboardContainer.Rows ; i++  )
            for( j = 0 ; j < StoryboardContainer.Cols ; j++ )
            {
                var src_id = MyIdGenerator.GenerateCellId( i , j );
 

                if( $( "#" + src_id ).length == 0 || !StoryboardContainer.GlobalCellCropRatio[src_id] ) 
                    continue;
 
                $( "#" + src_id ).attr( "A1" , StoryboardContainer.GlobalCellCropRatio[src_id].A1 );
                $( "#" + src_id ).attr( "A2" , StoryboardContainer.GlobalCellCropRatio[src_id].A2 );
                $( "#" + src_id ).attr( "A3" , StoryboardContainer.GlobalCellCropRatio[src_id].A3 );
                $( "#" + src_id ).attr( "B1" , StoryboardContainer.GlobalCellCropRatio[src_id].B1 );
                $( "#" + src_id ).attr( "B2" , StoryboardContainer.GlobalCellCropRatio[src_id].B2 );
                $( "#" + src_id ).attr( "B3" , StoryboardContainer.GlobalCellCropRatio[src_id].B3 );
            }
    }

    SaveDataHelperObject.GetSaveData = function (saveType , isLocalDB )
    {
        var storyboardSaveData = new Object();

        storyboardSaveData.MagicToken = MyUserPermissions.MagicToken;
        storyboardSaveData.RequestStart = (new Date()).toUTCString();
        storyboardSaveData.SaveTry = 1;

        // we store Global Cell Crop Ratio to SVG
        putGlobalCellCropRatioToCell();
         
        storyboardSaveData.Svg = GetRawSvg(saveType); 
        storyboardSaveData.SvgLength = storyboardSaveData.Svg.length;

        storyboardSaveData.ShapeStates = MyShapesState.Public_ShapeStateToJson(); 
        
        storyboardSaveData.ShapeStatesLength = storyboardSaveData.ShapeStates.length;

        storyboardSaveData.CharacterSwapLibrary = MyCharacterSwapLibrary.Public_GetJSON(MyShapesState);
        storyboardSaveData.CharacterSwapLibraryLength = storyboardSaveData.CharacterSwapLibrary.length;

        storyboardSaveData.LayoutConfig = JSON.stringify(CellConfiguration.GetLayoutConfig());
        storyboardSaveData.LayoutConfigLength = storyboardSaveData.LayoutConfig.length;

        

        storyboardSaveData.UseCompression = 0;

        storyboardSaveData.SaveDuration = +new Date();

        if (saveType == SaveDataHelper.NewStoryboard)
        {
            storyboardSaveData.Title = $("#StoryboardTitle").val();
            storyboardSaveData.Description = $("#StoryboardDescription").val();
            storyboardSaveData.PortalFolderId = $("#portal_folder_id").val();
        }
        else if (saveType == SaveDataHelper.EditStoryboard || saveType == SaveDataHelper.AutoSave)
        {
            storyboardSaveData.UrlTitle = $("#UrlTitle").val();
            storyboardSaveData.UserName = $("#EditUserName").val();
        }

        //if (saveType == SaveDataHelper.AutoSave)
        //{
        if( !isLocalDB )
        {
            storyboardSaveData.UsePmc = 1;
            storyboardSaveData.Svg = pmc(prePmc(storyboardSaveData.Svg));
            storyboardSaveData.SvgLength = storyboardSaveData.Svg.length;

            storyboardSaveData.ShapeStates = pmc(prePmc(storyboardSaveData.ShapeStates));
            storyboardSaveData.ShapeStatesLength = storyboardSaveData.ShapeStates.length;

            storyboardSaveData.CharacterSwapLibrary = pmc(storyboardSaveData.CharacterSwapLibrary);
            storyboardSaveData.CharacterSwapLibraryLength = storyboardSaveData.CharacterSwapLibrary.length;
        }
        //}
        return storyboardSaveData;
    };

    function GetRawSvg(saveType)
    {
        try
        {
            if (saveType == SaveDataHelper.AutoSave)
            {
                var svgCopy = $("#CoreSvg").clone();

                svgCopy.attr("style", "");
                svgCopy.find("[id$=selection_box]").remove()
                svgCopy.find("[id=SvgTop]").children().remove();

                return (new XMLSerializer()).serializeToString(svgCopy.get()[0]);
            }

            var svgById = GetGlobalById("CoreSvg");

            var style = svgById.getAttribute("style");
            svgById.setAttribute("style", "");
            var svg_xml = (new XMLSerializer()).serializeToString(svgById);
            svgById.setAttribute("style", style);

            return svg_xml;
        }
        catch (e)
        {
            LogErrorMessage("SaveDataHelper.GetRawSvg", e);
        }
    };

    function EscapeText(text)
    {

    }



    return SaveDataHelperObject;
}();