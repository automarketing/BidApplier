﻿var CopyHelper = function ()
{
    var CopyHelperObject = new Object();



    CopyHelperObject.CopyCellAction = function (sourceRow, sourceCol, destinationRow, destinationCol , isDelete)
    {
        var srcId = MyIdGenerator.GenerateCellId(sourceRow, sourceCol);
        var dstId = MyIdGenerator.GenerateCellId(destinationRow, destinationCol);

        // clone javascript object to save

        var CellCropRatioParam = {  id                : dstId , 
                                    undoCellCropRatio : StoryboardContainer.GlobalCellCropRatio[ dstId ] ? JSON.parse( JSON.stringify( StoryboardContainer.GlobalCellCropRatio[ dstId ] ) ) : null , 
                                    redoCellCropRatio : StoryboardContainer.GlobalCellCropRatio[ srcId ] ? JSON.parse( JSON.stringify( StoryboardContainer.GlobalCellCropRatio[ srcId ] ) ) : null  };

        StoryboardContainer.GlobalCellCropRatio[ dstId ] = StoryboardContainer.GlobalCellCropRatio[ srcId ] ? JSON.parse( JSON.stringify( StoryboardContainer.GlobalCellCropRatio[ srcId ] ) ) : null;


        var sourceCell      = $("#" + srcId );
        var destinationCell = $("#" + dstId );

        var deltaX = parseFloat(destinationCell.attr("x")) - parseFloat(sourceCell.attr("x"));
        var deltaY = parseFloat(destinationCell.attr("y")) - parseFloat(sourceCell.attr("y"));


        var shapeStatesAndParts = StoryboardContainer.GetShapeStatesForCell(sourceRow, sourceCol);
        
        var targetArray = { undoArray : [] , redoArray : [] } ;

        if( isDelete )
        {
            var DestState       = StoryboardContainer.GetShapeStatesForCell(destinationRow, destinationCol);
            var DestShapeStates = DestState[StoryboardPartTypeEnum.StoryboardCell];
            var undoArray = new Array();
            var redoArray = new Array();
            for (var i = 0; i < DestShapeStates.length; i++)
            {
                var activeShapeState = DestShapeStates[i];
                var id = activeShapeState.Id;
                var activeShape = $("#" + id);
    
                var nextShape = activeShape.next()
                var nextShapeId = nextShape.attr("id");
    
                redoArray.push({ Detached: activeShape, NextShapeId: nextShapeId, Id: id, ShapeState: MyShapesState.Public_GetShapeStateById(id) });
                undoArray.push({ Id: id });
    
                MyShapesState.Public_RemoveShapeStateById(id);
                var detached = $("#" + id).detach();
            }
            targetArray.undoArray = undoArray;
            targetArray.redoArray = redoArray;
        }
 

        var toCopyShapes = new Array();
        toCopyShapes = shapeStatesAndParts[StoryboardPartTypeEnum.StoryboardCell].concat(shapeStatesAndParts[StoryboardPartTypeEnum.StoryboardCellTitle], shapeStatesAndParts[StoryboardPartTypeEnum.StoryboardCellDescription]);

        var cell_title_id           = null; 
        var cell_title_txt          = null;
        var cell_title_color        = null; 
        var cell_description_id     = null; 
        var cell_description_txt    = null;
        var cell_description_color  = null; 

        if (CellConfiguration.HasTitle || CellConfiguration.HasDescription)
        {
            if (CellConfiguration.HasTitle)
            {
                cell_title_id       = MyIdGenerator.GenerateTitleCellId(destinationRow, destinationCol);
                var copyTo          = MyShapesState.Public_GetShapeStateById(cell_title_id);
                cell_title_txt      = copyTo.TextState.Public_GetFontStyles();
                cell_title_color    = copyTo.ColorableState.Public_GetColorStyles();
                var copyFrom = MyShapesState.Public_GetShapeStateById(MyIdGenerator.GenerateTitleCellId(sourceRow, sourceCol));
                CopyUnmovableText(copyTo, copyFrom);
            }

            if (CellConfiguration.HasDescription)
            {
                cell_description_id     = MyIdGenerator.GenerateDescriptionCellId(destinationRow, destinationCol);
                var copyTo              = MyShapesState.Public_GetShapeStateById(cell_description_id);
                cell_description_txt    = copyTo.TextState.Public_GetFontStyles();
                cell_description_color  = copyTo.ColorableState.Public_GetColorStyles();
                var copyFrom = MyShapesState.Public_GetShapeStateById(MyIdGenerator.GenerateDescriptionCellId(sourceRow, sourceCol));
                CopyUnmovableText(copyTo, copyFrom);
            }
        }

        var cell_text = null;
        if(cell_title_id || cell_description_id) 
            cell_text = 
            { 
                cell_title_id           : cell_title_id , 
                cell_title_txt          : cell_title_txt , 
                cell_title_color        : cell_title_color , 
                cell_description_id     : cell_description_id , 
                cell_description_txt    : cell_description_txt,
                cell_description_color  : cell_description_color 
            };

        CopyShapeHelper(toCopyShapes, deltaX, deltaY, false,true , cell_text , targetArray , true , CellCropRatioParam );

        ClearActiveState();
    }

    
    CopyHelperObject.CopyShape = function (e)
    {
        if (MyShapesState.Property_SelectedCount == 0)
        {
            return;
        } 

        var selectedShapeStates = MyShapesState.Public_GetAllSelectedMovableShapeStates(false);

        CopyShapeHelper(selectedShapeStates, 30, 30, true,false , null , null , false  );
    };

    CopyHelperObject.CopyCell = function (sourceRow, sourceCol, destinationRow, destinationCol)
    { 
        $("#CopyReplaceConfirm").show();
        $("#CopyReplaceConfirm").modal();
        $("#CopyReplaceConfirm_ReplaceBtn").off("click");
        $("#CopyReplaceConfirm_CopyBtn").off("click");
        $("#CopyReplaceConfirm_ReplaceBtn").click(function(e){
            CopyHelperObject.CopyCellAction(sourceRow, sourceCol, destinationRow, destinationCol , true);
            $("#CopyReplaceConfirm").hide();
        });
        $("#CopyReplaceConfirm_CopyBtn").click(function(e){
            CopyHelperObject.CopyCellAction(sourceRow, sourceCol, destinationRow, destinationCol , false)
            $("#CopyReplaceConfirm").hide();
        });
    };

    /**
     * This function can be used for both purpose of object-copy and cell-copy purpose 
     * targetArray is used when cell copy requires the delete of object in the destination cell
     * 
     * @param {*} selectedShapeStates 
     * @param {*} xOffset 
     * @param {*} yOffset 
     * @param {*} useSafetyMargins 
     * @param {*} copyLockState 
     * @param {*} cell_text 
     * @param {*} targetArray 
     * @param {*} isCellCopy 
     */

    function CopyShapeHelper(selectedShapeStates, xOffset, yOffset, useSafetyMargins, copyLockState, cell_text , targetArray , isCellCopy, CellCropRatioParam  )
    {
        try
        { 
            var newShapes = new Array();

            selectedShapeStates.sort(Sorters.SortShapeStatesByIndex);
 
            for (var i = 0; i < selectedShapeStates.length; i++)
            {
                var active = selectedShapeStates[i]; 
                var id = active.Id + "_natural";
                var shape = $("#" + id).clone();

                StoryboardContainer.UpdateGradientIds(shape);

                var x = active.X + xOffset;  // this is correct because hte copy will have the same screwy offsets, possible some issues, but i think ok abs 8/13/13
                var y = active.Y + yOffset;

                if (useSafetyMargins)
                {
                    var W = CellPickerHelper.Props.CoreSVGRegion.state ? CellPickerHelper.Props.CoreSVGRegion.width  : $("#CoreSvg").width();
                    var H = CellPickerHelper.Props.CoreSVGRegion.state ? CellPickerHelper.Props.CoreSVGRegion.height : $("#CoreSvg").height();
     
                    if (x + 50 > W )
                    {
                        x = active.X - xOffset;
                    }
                    if (y + 50 > H )
                    {
                        y = active.Y - yOffset;
                    }
                } 

                var newShape = AddSvg.AddSvgToStoryboard( shape , x , y , false , active.isSceneItem );
                newShapes.push(newShape);

                var newShapeState = MyShapesState.Public_GetShapeStateByShape(newShape);

                newShapeState.CopyShapeState(active);
                
                newShapeState.MoveTo(x, y);

                if (copyLockState)
                {
                    newShapeState.IsLocked = active.IsLocked;
                }
            }

            var undoArray = new Array();
            var redoArray = new Array();

            ClearActiveState();
            
            for (var j = 0; j < newShapes.length; j++)
            {
                var newShape = newShapes[j];
                var id = newShape.attr("id");

                undoArray.push({ Id: id });
                redoArray.push({ Id: id, Detached: newShape, NextShapeId: newShape.next().attr("id"), ShapeState: MyShapesState.Public_GetShapeStateById(id) });

                MyShapesState.Public_SelectShape(newShape);
       
            }

            if( cell_text )
                undoArray.push({ Id: null , content : cell_text });

            // console.log(undoArray);

            MyShapesState.Property_SetCurrentShapeAction(ShapeActionEnum.Selected);

            UndoManager.register(undefined, UndoCellCopy, [undoArray , targetArray ? targetArray.redoArray : redoArray , isCellCopy , CellCropRatioParam ? CellCropRatioParam.id : null , CellCropRatioParam ? CellCropRatioParam.undoCellCropRatio : null ], undefined, '', 
                                            RedoCellCopy, [redoArray , targetArray ? targetArray.undoArray : undoArray , isCellCopy , CellCropRatioParam ? CellCropRatioParam.id : null , CellCropRatioParam ? CellCropRatioParam.redoCellCropRatio : null ], '');
                
            UpdateActiveDrawing();
        }
        catch (e)
        {
            LogErrorMessage("SvgManip.CopyShapeHelper", e);
        }
    }

    function UndoCellCopy()
    {
        var undoArray            = arguments[0];
        var targetArrayredoArray = arguments[1];
        var isCellCopy           = arguments[2];
        var CellCropRatioId      = arguments[3];
        var CellCropRatio        = arguments[4];
 
        UndoShapeAdd.apply( this , undoArray );

        if( targetArrayredoArray && isCellCopy )
            UndoDeleteShape.apply( this , targetArrayredoArray );

        if( CellCropRatioId )
            StoryboardContainer.GlobalCellCropRatio[ CellCropRatioId ] = CellCropRatio ;
    }


    function CopyUnmovableText(copyTo, copyFrom)
    {
        if (copyTo == null || copyFrom == null)
            return;

        // if there is already non default text, don't copy it!
        if (copyTo.TextState.D[copyTo.TextState.CurrentId].Text != "" && copyTo.TextState.D[copyTo.TextState.CurrentId].Text != copyTo.TextState.D[copyTo.TextState.CurrentId].DefaultText )
            return;

        // if there is no text, or just default text, don't copy it
        if (copyFrom.TextState.D[copyFrom.TextState.CurrentId].Text == "" || copyFrom.TextState.D[copyFrom.TextState.CurrentId].Text == copyFrom.TextState.D[copyFrom.TextState.CurrentId].DefaultText)
            return;

        //copies text and font
        copyTo.TextState.CopyFontStyles(copyFrom.TextState.Public_GetFontStyles());
        copyTo.ColorableState.Public_CopyColorStyles(copyFrom.ColorableState.Public_GetColorStyles());
        copyTo.UpdateDrawing(); 
    };

    function RedoCellCopy()
    {
        var redoArray            = arguments[0];
        var targetArrayundoArray = arguments[1];
        var isCellCopy           = arguments[2];
        var CellCropRatioId      = arguments[3];
        var CellCropRatio        = arguments[4];

        UndoDeleteShape.apply( this ,  redoArray );
        if( targetArrayundoArray && isCellCopy )
            UndoShapeAdd.apply( this ,  targetArrayundoArray );

        if( CellCropRatioId )
            StoryboardContainer.GlobalCellCropRatio[ CellCropRatioId ] = CellCropRatio ;
    }
    return CopyHelperObject;
}();