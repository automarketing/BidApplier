<?php

/*------------- output -----------------*/

function get_list( $per_page = 25, $page_number = 1 ) {
	// fetch out ip list with all column
	global $wpdb;
	$sql = "
		select * from wp_useractivity
	";

	$display_limit = $wpdb->get_var( "select value from wp_useracitivity_opt where option='display_limit'" );

	if ( ! empty( $_REQUEST['orderby'] ) ) {
			$sql .= ' ORDER BY ' . esc_sql( $_REQUEST['orderby'] );
			$sql .= ! empty( $_REQUEST['order'] ) ? ' ' . esc_sql( $_REQUEST['order'] ) : ' ASC';
		}
	else $sql .= ' ORDER BY time desc';

	$sql .= " LIMIT $per_page";
	$sql .= ' OFFSET ' . ( $page_number - 1 ) * $per_page;

	$result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;	
}

function record_count() {

	// get count of record

	global $wpdb;
	$sql = "
		select count(*) from wp_useractivity	
	";

	return $wpdb->get_var( $sql );

}

function last_record()
{
	global $wpdb;
	$sql = "
		select max(UID) from wp_useractivity	
	";

	return $wpdb->get_var( $sql );
}
 


class AN_Plugin {

	// class instance
	static $instance;

	// customer WP_List_Table object
	public $customers_obj;

	// class constructor
	public function __construct() {
		add_filter( 'set-screen-option', [ __CLASS__, 'set_screen' ], 10, 3 );
		add_action( 'admin_menu', [ $this, 'plugin_menu' ] );
	}


	public static function set_screen( $status, $option, $value ) {
		return $value;
	}


//////////////////////////////////////////////////////// show setting //////////////////////////////////////////////////////////////////

	public static function showsetting()
	{
		require_once('BackSetting.php');	 
	}

	public function plugin_menu() {

		$hook = add_menu_page(
			'Anonymous Visit',
			'Anonymous Visit',
			'edit_pages',
			'total_activity_main',
			[ $this, 'main_page_build' ]
		);

		add_submenu_page('total_activity_main', 'Config', 'Config', 'edit_pages' , 'submenu' , [ $this, 'showsetting' ] );

		add_action( "load-$hook", [ $this, 'screen_option' ] );

	}
	public function main_page_build()
	{
		?>		
		<div class="wrap">

			<?php
				back_main_tab( 0 );
			?>
		        <br>
		        <br>
			<h1>
			Total Activity
			</h1>
			<br>
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
					<div id="post-body-content">
						<div class="tablenav-pages">
							<input type='hidden' name='last_record_uid' id='last_record_uid' value='9999999'>
							<span class="displaying-num" id='total_item'>2 items</span>
							<a id='go_first'    style='cursor:pointer'><span class="tablenav-pages-navspan" aria-hidden="true">«</span></a>
							<a id='go_previous' style='cursor:pointer'><span class="tablenav-pages-navspan" aria-hidden="true">‹</span></a>							
							<label for="current-page-selector" class="screen-reader-text">Current Page</label>
							<input class="current-page" id="current_page" type="text" name="current_page" value="1" size="1" aria-describedby="table-paging">
							<span class="tablenav-paging-text"> of <input id="total_page" value="2" disabled style="text-align:center;  border:none; width:90px;" ></span>
							<a id='go_next' style='cursor:pointer'><span class="tablenav-pages-navspan" aria-hidden="true">›</span></a>
							<a id='go_last' style='cursor:pointer'><span class="tablenav-pages-navspan" aria-hidden="true">»</span></a>
						</div>
						<div class="meta-box-sortables ui-sortable" id="mainTableDiv">
							 
						</div>
					</div>
				</div>
				<br class="clear">
			</div>
		</div>
	<?php
	}

	public function screen_option() {

		$option = 'per_page';
		$args   = [
			'label'   => 'Customers',
			'default' => 25,
			'option'  => 'customers_per_page'
		];

		add_screen_option( $option, $args );
 
	}


	/** Singleton instance */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


}


add_action( 'plugins_loaded', function () {
	AN_Plugin::get_instance();
} );






//////// ajax update

function dobsondev_ajax_total_activity_front_end() {
  ?>
  <script type="text/javascript" >
  

  jQuery(document).ready(function($) 
  {
	refresh_data();
	function fetch_out_page_information( )
	{
		$.ajax({
		          method: "POST",
		          url: ajaxurl,
		          data: { 'action': 'dobsondev_ajax_total_activity_page_information', 
				  	  'customers_per_page' : $( '#customers_per_page' ).val() ,  
					  'current_page' : $( '#current_page' ).val() ,
			  }

		})
		.done(function( data ) 
	        {
				console.log(data);
	           var D = JSON.parse(data);
			   $("#total_page").val( D.total_page );
			   $("#total_item").html( D.total_item + " items");
			   $("#last_record_uid").val(D.last_record_uid);
			   setTimeout( refresh_data , 5000 );
	        })
 
	}

	    function refresh_data()
	    {


		$.ajax({
	          method: "POST",
	          url: ajaxurl,
	          data:  {
				  'action': 'dobsondev_ajax_total_activity_refresh_data', 
				  'customers_per_page' : $( '#customers_per_page' ).val() ,  
				  'current_page' : $( '#current_page' ).val() ,
				  'last_record_uid' : $('#last_record_uid').val(),
			  }
	        })
	        .done(function( data ) 
	        {
				$("#mainTableDiv").html(data);
				fetch_out_page_information();
				
	        })

	        .fail(function( data ) {
	          console.log('Failed AJAX Call :( /// Return Data: ' + data);
	        });
			
		
	}

    $( '#changefieldbtn' ).click( function() 
    {
       process_data();
    });

	$( '#updateDatabtn' ).click( function() 
    {
       refresh_data();
    });

	$('#go_first').click( function()
	{
		$('#current_page').val( 1 );
		refresh_data();
	});

	$('#go_last').click( function()
	{
		$('#current_page').val( $('#total_page').val() );
		refresh_data();
	});

	$('#go_next').click( function()
	{
		var p = $('#current_page').val();
		if( p < $('#total_page').val() )
		{
			$('#current_page').val( p * 1 + 1 );
			refresh_data();
		}
	});

	$('#go_previous').click( function()
	{
		var p = $('#current_page').val();
		if(  p > 0 )
		{
			$('#current_page').val( p * 1 - 1 );
			refresh_data();
		}
	});

	
  });

	function view_company_detail( company )
	{ 
		<?php

		 $link = add_query_arg(
		            array(
		                'page' => 'company_history'
		            ),
		            admin_url('admin.php')
		        );
		 echo "window.open('".$link."&company='+company,'_self');";
		?>
		
	};
  </script>
  <?php
}

 
function ajax_total_activity_table_response() {

	global $wpdb;

	$v = $wpdb->get_var( "select value from wp_useracitivity_opt where option='keep_period'" );
 
	$wpdb->query( "delete from wp_useractivity where DATE_FORMAT(time,'%Y-%m-%d')<'".date('Y-m-d', strtotime('-'.$v.' days'))."'"  );

	 
	$dTable = get_list( $_POST['customers_per_page'] , $_POST['current_page']  );

?>
	<table class="widefat">
	<thead>
	     <tr> 
		<th>Company</th>
		<th>IP/DNS</th>
		<th>Page</th>
		<th>Device/OS</th>
		<th>Time</th>
		<th>Country</th>	
		<th>Region/City</th>
		<th>Tel</th>
		<th>Email</th> 
	     </tr>
	 </thead>
	 <tbody>

     <?php
	 for( $i = 0 ; $i < count($dTable) ; $i++ ) 
	 {
		 $td_style = " ";
		 if( $dTable[$i]['UID'] > $_POST['last_record_uid'] )
		 	$td_style = " style='color:red'; ";

	 ?>
     <tr>
	<td <?php echo $td_style; ?>  ><a style='cursor:pointer' onclick='view_company_detail(this.innerHTML);'  <?php echo $td_style; ?>><?php echo $dTable[$i]['Company']; ?></a></td>
	<td <?php echo $td_style; ?>><?php echo $dTable[$i]['IP']; ?><br><?php echo $dTable[$i]['DNS']; ?></td>
	<td <?php echo $td_style; ?>><?php echo $dTable[$i]['Page']; ?></td>
	<td <?php echo $td_style; ?>><?php echo $dTable[$i]['Device']; ?><br><?php echo $dTable[$i]['OS']; ?></td>
	<td <?php echo $td_style; ?>><?php echo $dTable[$i]['time']; ?></td>
	<td <?php echo $td_style; ?>><?php echo $dTable[$i]['Country']; ?></td>
	<td <?php echo $td_style; ?>><?php echo $dTable[$i]['Region']; ?><br><?php echo $dTable[$i]['City']; ?></td>
	<td <?php echo $td_style; ?>><?php echo $dTable[$i]['Tel']; ?></td>
	<td <?php echo $td_style; ?>><?php echo $dTable[$i]['email']; ?></td>
     </tr>
     <?php } ?>
	</tbody>
   </table>
<?php
	die;
}
function ajax_total_activity_page_infor()
{ 
	$total_items  = record_count();
	$last_record_uid  = last_record();	

	$res['total_item'] = $total_items;
	$res['last_record_uid'] = $last_record_uid;
	$res['total_page'] = round($total_items /  $_POST['customers_per_page']) + ( $total_items % $_POST['customers_per_page'] > 0 ? 1 : 0) ;
	echo json_encode($res);
	die;
}


add_action( 'wp_ajax_dobsondev_ajax_total_activity_refresh_data', 'ajax_total_activity_table_response' );
add_action( 'wp_ajax_dobsondev_ajax_total_activity_page_information', 'ajax_total_activity_page_infor' );
add_action( 'admin_footer', 'dobsondev_ajax_total_activity_front_end' );

