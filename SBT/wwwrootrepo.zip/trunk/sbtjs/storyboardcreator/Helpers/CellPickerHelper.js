﻿
var CellPickerHelper = function ()
{
    var CellPickerHelperObject = new Object();
    
    var Props = new Object();
    
    Props.SelectedCell = null;
    Props.ActionType = "";
    Props.UndoCount = 0;
    Props.ActionMethod = null;
    
    Props.CopyActionType = "copy";
    Props.MoveActionType = "move";

    Props.WidthRatio = 1;

    Props.CoreSVGRegion = {
        width : 0 , 
        height : 0 ,
        margin : '' ,
        state : false
    };

    Props.CalcPoint = document.getElementById("CoreSvg").createSVGPoint();

    CellPickerHelperObject.Props = Props;

    function ToggleMaxSize ()
    {
        //remove top controls
        $("#StoryboardCreatorWrapper").toggle();
        $(".Upgrade-Bar").toggleClass("hide-in-fullscreen");    // we don't want to turn on the ad bars when super tiny
        $("#bottom-toolbar-controls").toggle();
        $("#bottom-toolbar-advice").toggle();
        $("#tab-roller").toggle();
        $("#bt-copy-cell-undo").css("display", "none");

        StoryboardContainer.JiggleSvgSize();
        StoryboardContainer.SetCoreSvgDimensions();
    };

    function SaveStageState()
    {
        if( !Props.CoreSVGRegion.state )
        {
            Props.CoreSVGRegion = { 
                width  : document.getElementById("CoreSvg").getAttributeNS( null , "width"  ) ,
                height : document.getElementById("CoreSvg").getAttributeNS( null , "height" ) ,
                margin : $("#CoreSvg").css('margin' ) ,
                state  : true
            };
        }
    }

    function restoreStageState()
    {
        document.getElementById("CoreSvg").setAttributeNS( null , "width"  , Props.CoreSVGRegion.width ) ; 
        document.getElementById("CoreSvg").setAttributeNS( null , "height" , Props.CoreSVGRegion.height ) ;
 
        $("#CoreSvg").css( "margin"  , Props.CoreSVGRegion.margin );

        Props.CoreSVGRegion.state = false;
    }

    CellPickerHelperObject.getScreenPointFromSVG = function( x , y )
    {
        Props.CalcPoint.x = x;
        Props.CalcPoint.y = y;
        return Props.CalcPoint.matrixTransform( document.getElementById("CoreSvg").getScreenCTM() );
    }

    CellPickerHelperObject.getSVGPointFromScreen = function( x , y )
    {
        Props.CalcPoint.x = x;
        Props.CalcPoint.y = y;
        return Props.CalcPoint.matrixTransform( document.getElementById("CellDefinition").getScreenCTM().inverse() );
    }

    function DrawOverlay ()
    {
        // set viewbox on current object

        SaveStageState();

        var screenW = $(window).width();
        var screenH = $(window).height();
        
        var coreSVGWidth  = screenW - 10;
        var coreSVGHeight = screenH - 70 - 10;
                        
        document.getElementById("CoreSvg").setAttribute( "viewBox" , 0 + " " + 0  + " " +  Props.CoreSVGRegion.width  + " " +  Props.CoreSVGRegion.height );
 
        document.getElementById("CoreSvg").setAttributeNS( null , "width"  , coreSVGWidth  ) ; 
        document.getElementById("CoreSvg").setAttributeNS( null , "height" , coreSVGHeight ) ;

        Props.WidthRatio = Props.CoreSVGRegion.width / coreSVGWidth;

        

        $("#CoreSvg").css( "margin" , "5 5 5 5" );
        $("#cell-overlay-helper").remove();

        MyPointers.SvgContainer.css( "position", "fixed" );
        MyPointers.SvgContainer.append( "<div id='cell-overlay-helper' class='cell-overlay-parent-div'></div>" );

        var cellOverlayDiv = $("#cell-overlay-helper");
        
        var svgContainerHeight = parseFloat( MyPointers.SvgContainer.css("height") );
        var svgContainerWidth  = parseFloat( MyPointers.SvgContainer.css("width") );

        cellOverlayDiv.css( "height" , svgContainerHeight + "px" );
        cellOverlayDiv.css( "width"  , svgContainerWidth  + "px" );
        cellOverlayDiv.css( "margin" , "0" );
        
        
        for (var col = 0; col < StoryboardContainer.Cols; col++)
        {
            for (var row = 0; row < StoryboardContainer.Rows; row++)
            {

                var cellPosition = CellConfiguration.GetCellPartPosition(StoryboardPartTypeEnum.StoryboardCell, row, col);
                var screenPoint = CellPickerHelper.getScreenPointFromSVG( cellPosition.X , cellPosition.Y );
                var screenPointEnd = CellPickerHelper.getScreenPointFromSVG( cellPosition.X + cellPosition.Width , cellPosition.Y + cellPosition.Height );

                var Width  = screenPointEnd.x - screenPoint.x;
                var Height = screenPointEnd.y - screenPoint.y;
  
               AddCellOverlay(cellOverlayDiv,  screenPoint.x, screenPoint.y, Width , Height , row, col, StoryboardPartTypeEnum.StoryboardCell);

                 if (CellConfiguration.HasTitle)
                     AddCellPartOverlay(cellOverlayDiv, screenPoint.x, screenPoint.y, Width , Height, row, col, StoryboardPartTypeEnum.StoryboardCellTitle);

                 if (CellConfiguration.HasDescription)
                     AddCellPartOverlay(cellOverlayDiv, screenPoint.x, screenPoint.y, Width , Height, row, col, StoryboardPartTypeEnum.StoryboardCellDescription);
            }
        }
    }

    function AddCellOverlay (cellOverlayDiv , X , Y , W , H , row , col , part)
    {
        var cell = $("#" + MyIdGenerator.GenerateCellId(row, col));
        if (cell.length == 0) { return; }

        var id = MyIdGenerator.GenerateCellOverlayId(row, col, part);
        cellOverlayDiv.append("<div id='" + id + "' class='cell-overlay-cell'></div>");

        var strokeWidth = parseFloat(cell.attr("stroke-width")) / 2;
        strokeWidth = isNaN(strokeWidth) ? 0 : strokeWidth ;

        var cellOverlay = $("#" + id);
 

        cellOverlay.css("top"   , Y + "px");
        cellOverlay.css("left"  , X + "px");
        cellOverlay.css("width", W + "px");
        cellOverlay.css("height" , H + "px");

        cellOverlay.click(OnCellSelected(row, col));
    }

    function AddCellPartOverlay (cellOverlayDiv,  paddingTop, paddingLeft, row, col, part)
    {
        var partPosition = CellConfiguration.GetCellPartPosition(part, row, col)
        if ( !partPosition || partPosition.length == 0) { return; }

        var id = MyIdGenerator.GenerateCellOverlayId(row, col, part);
        cellOverlayDiv.append("<div id='" + id + "' class='cell-overlay-cell'></div>");

        var cellOverlay = $("#" + id);

        var cellLeft =  paddingLeft + partPosition.X;
        var cellTop = paddingTop + partPosition.Y;

        cellOverlay.css("top", cellTop + "px");
        cellOverlay.css("left", cellLeft + "px");
        cellOverlay.css("height", partPosition.Height + "px");
        cellOverlay.css("width", partPosition.Width + "px");

        cellOverlay.click(OnCellSelected(row, col));
    }


    function OnCellSelected (row, col)
    {
        //var props = Props;

        return function ()
        {
            if (Props.SelectedCell == null)
            {
                $("#" + MyIdGenerator.GenerateCellOverlayId(row, col, StoryboardPartTypeEnum.StoryboardCell)).addClass("cell-overlay-cell-selected");
                $("#" + MyIdGenerator.GenerateCellOverlayId(row, col, StoryboardPartTypeEnum.StoryboardCellDescription)).addClass("cell-overlay-cell-selected");
                $("#" + MyIdGenerator.GenerateCellOverlayId(row, col, StoryboardPartTypeEnum.StoryboardCellTitle)).addClass("cell-overlay-cell-selected");

                Props.SelectedCell = new Object({ Row: row, Col: col });
                UpdateHelpMessage(2);

            }
            else
            {
                $("#" + MyIdGenerator.GenerateCellOverlayId(Props.SelectedCell.Row, Props.SelectedCell.Col, StoryboardPartTypeEnum.StoryboardCell)).removeClass("cell-overlay-cell-selected");
                $("#" + MyIdGenerator.GenerateCellOverlayId(Props.SelectedCell.Row, Props.SelectedCell.Col, StoryboardPartTypeEnum.StoryboardCellDescription)).removeClass("cell-overlay-cell-selected");
                $("#" + MyIdGenerator.GenerateCellOverlayId(Props.SelectedCell.Row, Props.SelectedCell.Col, StoryboardPartTypeEnum.StoryboardCellTitle)).removeClass("cell-overlay-cell-selected");

                //unselect!
                if (Props.SelectedCell.Row == row && Props.SelectedCell.Col == col)
                    UpdateHelpMessage(1);
                else
                {
                    Props.ActionMethod(Props.SelectedCell.Row, Props.SelectedCell.Col, row, col)
                    UpdateHelpMessage(3);
                    
                }

                Props.SelectedCell = null;
                CellPickerHelper.UpdateIfNeeded();
            }
        };
    }

    function UpdateHelpMessage (step)
    {

        $("#bt-copy-part-1").css("display", "none");
        $("#bt-copy-part-2").css("display", "none");
        $("#bt-copy-part-3").css("display", "none");

        $("#bt-move-part-1").css("display", "none");
        $("#bt-move-part-2").css("display", "none");
        $("#bt-move-part-3").css("display", "none");


        $("#bt-" + Props.ActionType + "-part-" + step).css("display", "");

        if (step == 3)
        {
            $("#bt-copy-cell-undo").css("display", "");
            Props.UndoCount++;
        }

        
    }

    function PrepareCellPickerHelper ()
    {
        Props.UndoCount = 0;
        Props.SelectedCell = null;

        ClearActiveState();

        UpdateHelpMessage(1);

        ToggleMaxSize();

        

        DrawOverlay();
    };

    CellPickerHelperObject.UndoHelper = function ()
    {
        Undo();
        Props.UndoCount--;
        if (Props.UndoCount < 1)
        {
            $("#bt-copy-cell-undo").css("display", "none");
        }
    };

    CellPickerHelperObject.UpdateIfNeeded = function ()
    {
        if (Props.ActionType == "")
            return;
        if ($("#cell-overlay-helper").length == 0)
            return;

        DrawOverlay();

        if (Props.SelectedCell != null)
        {
            $("#" + MyIdGenerator.GenerateCellOverlayId(Props.SelectedCell.Row, Props.SelectedCell.Col, StoryboardPartTypeEnum.StoryboardCell)).addClass("cell-overlay-cell-selected");
            $("#" + MyIdGenerator.GenerateCellOverlayId(Props.SelectedCell.Row, Props.SelectedCell.Col, StoryboardPartTypeEnum.StoryboardCellDescription)).addClass("cell-overlay-cell-selected");
            $("#" + MyIdGenerator.GenerateCellOverlayId(Props.SelectedCell.Row, Props.SelectedCell.Col, StoryboardPartTypeEnum.StoryboardCellTitle)).addClass("cell-overlay-cell-selected");
        }

    };

    function updateAllCellObject()
    {
        // update all object
        var allShapeStates = MyShapesState.Public_GetAllShapeStates();
        var i;
        for( i = 0 ; i < allShapeStates.length ; i++ )
            allShapeStates[i].UpdateDrawing( true );
    }

    CellPickerHelperObject.StartCopyCell = function ()
    {
        Props.ActionType = Props.CopyActionType;
        Props.ActionMethod = CopyHelper.CopyCell;
        
        PrepareCellPickerHelper();
        updateAllCellObject();
    };

    CellPickerHelperObject.StartMoveCell = function ()
    {
        Props.ActionType = Props.MoveActionType;
        //Props.ActionMethod = MoveCellHelper.MoveCell;
        Props.ActionMethod = MoveCellHelper.SwapCell;
        
        PrepareCellPickerHelper();
        updateAllCellObject();
    };

 

    CellPickerHelperObject.Finish = function ()
    {
        MyPointers.SvgContainer.css("position", "fixed");

        restoreStageState();

        $("#cell-overlay-helper").remove();

        document.getElementById("CoreSvg").removeAttribute( "viewBox" );
        ToggleMaxSize();

        Props.WidthRatio = 1;

        updateAllCellObject();
        Props.ActionType = null;

    };

    return CellPickerHelperObject;
}();

