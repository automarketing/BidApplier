﻿this.StoryboardLayoutType =
       {
           StoryboardGrid: "StoryboardGrid",
           TChart: "TChart",
           Frayer: "Frayer",
           Spider: "Spider",
           Timeline: "Timeline",
           Matrix: "Matrix",
           Movie: "Movie",
           ParallelLabelMatrix: "ParallelLabelMatrix",
           Cycle: "Cycle"
       };
