﻿var ZoomCropHelper = function ()
{
    var ZoomCropHelperObject = new Object();

    var Props = new Object();

    Props.CropLeft = 0;
    Props.CropTop = 0;
    Props.CropHeight = 0;
    Props.CropWidth = 0;
    Props.CropRatio = 1;
    
    Props.CropViewScale;
    Props.ClipScale;
    Props.ImageWidth = 0;
    Props.ImageHeight = 0;

    Props.CropAction = "";
    Props.ResizePageX = 0;
    Props.ResizePageY = 0;
    Props.CropResizeDirection = "";
    Props.CircleSizeRatio = 1;
    Props.CroppedImageCopyId = "ZoomCroppedImageCopy";
    Props.CalcPoint = document.getElementById("ZoomCropAreaSvg").createSVGPoint();
    Props.selectedShapeStates = new Array();
    Props.CellPosition = null;
    Props.newScale = 1;
    Props.CellHash = 0;

    Props.CellId = null;
    Props.PrevCellCropRatio  = null;
    Props.PrevCellCropLength = null;
    Props.PrevCellCropArea   = null;
    Props.PrevScale = null; 

    Props.ViewArea = null;

    function PrepareShapePostModalClosure(activeShape)
    {
        return function (e)
        {
            PrepareShapePostModal( activeShape );
        };
    };


    /**
     * Previous Cell Parameter Crop on the stage before cropping
     * We have to think Total Cell size =  Props.CellPosition.Width , Height
     * 
     */

    function getPrevCellCropLength()
    {
        var TotalRatioW = Props.PrevCellCropRatio.A1 + Props.PrevCellCropRatio.A2 + Props.PrevCellCropRatio.A3;
        var TotalRatioH = Props.PrevCellCropRatio.B1 + Props.PrevCellCropRatio.B2 + Props.PrevCellCropRatio.B3;

        var LengthA1 = Props.CellPosition.Width * Props.PrevCellCropRatio.A1 / TotalRatioW ;
        var LengthA2 = Props.CellPosition.Width * Props.PrevCellCropRatio.A2 / TotalRatioW ;
        var LengthA3 = Props.CellPosition.Width * Props.PrevCellCropRatio.A3 / TotalRatioW ;

        var LengthB1 = Props.CellPosition.Height * Props.PrevCellCropRatio.B1 / TotalRatioH ;
        var LengthB2 = Props.CellPosition.Height * Props.PrevCellCropRatio.B2 / TotalRatioH ;
        var LengthB3 = Props.CellPosition.Height * Props.PrevCellCropRatio.B3 / TotalRatioH ;
        

        return { LengthA1 : LengthA1 , LengthA2 : LengthA2 , LengthA3 : LengthA3   , 
                 LengthB1 : LengthB1 , LengthB2 : LengthB2 , LengthB3 : LengthB3   };
    }

    function getPrevCellCropArea()
    {
        return {
            X       : Props.CellPosition.X + Props.PrevCellCropLength.LengthA1 ,
            Y       : Props.CellPosition.Y + Props.PrevCellCropLength.LengthB1 ,
            Width   : Props.PrevCellCropLength.LengthA2 ,
            Height  : Props.PrevCellCropLength.LengthB2
        };
    }

    function getPreviousScale()
    {
        return  ( Props.PrevCellCropRatio.A1 + Props.PrevCellCropRatio.A2 + Props.PrevCellCropRatio.A3 ) / Props.PrevCellCropRatio.A2;
    }

    /**
     * [ A1 , A2 , A3 , B1 , B2 , B3 ] in the current view Stage ( Scaled Stage ) 
     * Total Cell size is BigA1 + BigA2 + BigA3
     * 
     */

    function getViewArea()
    {
        var BigA1 = Props.CellPosition.Width * Props.PrevCellCropRatio.A1  / Props.PrevCellCropRatio.A2  ;
        var BigA2 = Props.CellPosition.Width ;
        var BigA3 = Props.CellPosition.Width * Props.PrevCellCropRatio.A3  / Props.PrevCellCropRatio.A2 ;

        var BigB1 = Props.CellPosition.Height * Props.PrevCellCropRatio.B1  / Props.PrevCellCropRatio.B2  ;
        var BigB2 = Props.CellPosition.Height ;
        var BigB3 = Props.CellPosition.Height * Props.PrevCellCropRatio.B3  / Props.PrevCellCropRatio.B2 ;

        return {
            X      : Props.CellPosition.X - BigA1 ,
            Y      : Props.CellPosition.Y - BigB1 ,
            Width  :  BigA1 + BigA2 + BigA3 ,
            Height :  BigB1 + BigB2 + BigB3
        } ; 
    }


    function PrepareShapePostModal(activeShape)
    {
        //pDos 2017
        var cropAreaSvg = $("#ZoomCropAreaSvg");
        Props.CropAction = "";
        cropAreaSvg.children().remove();

        if( Props.selectedShapeStates )
            for (var i = 0; i < Props.selectedShapeStates[StoryboardPartTypeEnum.StoryboardCell].length; i++)
            {
                var active = Props.selectedShapeStates[StoryboardPartTypeEnum.StoryboardCell][i];
                var shape = $("#" + active.Id).clone();
                shape.find("[id$='selection_box'], [id$='_defs']").remove();
                shape.find("#" + active.Id + "_cropGroup").removeAttr("clip-path");
                cropAreaSvg.append(shape);
            }
 

        Props.CropViewScale = 1; 

        Props.CropLeft   = Props.CellPosition.X;
        Props.CropTop    = Props.CellPosition.Y;
        Props.CropWidth  = Props.CellPosition.Width - 1;
        Props.CropHeight = Props.CellPosition.Height - 1;
        Props.CropRatio  = Props.CellPosition.Height / Props.CellPosition.Width;

        Props.PrevCellCropLength = getPrevCellCropLength();
        Props.PrevCellCropArea   = getPrevCellCropArea(); 
        Props.PrevScale          = getPreviousScale();
        Props.ViewArea           = getViewArea();

        // console.log( Props.PrevCellCropRatio );
        // console.log( Props.PrevCellCropLength );
        // console.log( Props.PrevCellCropArea );
        // console.log( Props.ViewArea );
        // console.log( Props.PrevScale );
        
        var DX = Props.ViewArea.X      - 10;
        var DY = Props.ViewArea.Y      - 10;
        var DW = Props.ViewArea.Width  + 20;
        var DH = Props.ViewArea.Height + 20;

        document.getElementById("ZoomCropAreaSvg").setAttribute( "viewBox" , DX + " " + DY  + " " +  DW  + " " +  DH );

        var DivW =  Math.round( $(window).width()  * 8 / 10  );
        var DivH =  Math.round( $(window).height() * 8 / 10  ) - 130; // 130 : header and footer of modal dialog
        var OneLength = DivW > DivH ? DivH : DivW;
        var OuterW1 = OneLength , OuterH1 = OneLength;
 

        $("#ZoomCropModalDialog").css( "width"  , Math.max( OuterW1 + 50 , 350 ) );
        $("#ZoomCropModalDialog").css( "height" , OuterH1 );

        $(".crop-window-wrapper").css( "width" , OuterW1 );
        $(".crop-window-wrapper").css( "height", OuterH1 );

        var svg_margin = 20;
        cropAreaSvg.attr("width" ,  OuterW1 - svg_margin );
        cropAreaSvg.attr("height",  OuterH1 - svg_margin );

        cropAreaSvg.mousemove(HandleCropMoveClosure());
        cropAreaSvg.mouseleave(StopCropResizeClosure());
        cropAreaSvg.mouseup(StopCropResizeClosure());
        cropAreaSvg.mousedown(StartCropAreaMoveClosure());
        cropAreaSvg.css("cursor", "hand");

        AddSelectors();  
    };

    //#region "Selectors"
    function AddSelectors()
    {
        var g = $("#croppedImageCopy_ClipArea");
        if (g !== null || g.length > 0)
        {
            g.detach();
        }
        g = SvgCreator.CreateSvgGroup("croppedImageCopy_ClipArea");

        $( "#ZoomCropAreaSvg" ).append(g);

        g.appendChild(SvgCreator.AddRect(Props.CropLeft, Props.CropTop, Props.CropWidth, Props.CropHeight, "black", "red", "4,4", ".25", "ZoomCropAreaBox"));
 
        if (MyBrowserProperties.IsMobile)
        {
            AddMobileSelectors(g);
        }
        else
        {
            AddComputerSelectors(g);
        }
    };

    function AddMobileSelectors(g)
    { 
        var circleSize = 13 ;
        var strokeColor = "#AAA393";
        var fillColor = "#6285C7";

        var cropAreaBox = $("#ZoomCropAreaBox");
        cropAreaBox.css("border-width", 5);
        
        var left = Props.CropLeft;
        var right = Props.CropWidth + Props.CropLeft;
        var top = Props.CropTop;
        var bottom = Props.CropHeight + Props.CropTop;

        g.appendChild(SvgCreator.AddCircle(left, top, circleSize, strokeColor, fillColor, Props.CroppedImageCopyId + "_nw_circle", "ResizeNW"));
        g.appendChild(SvgCreator.AddCircle(right, top, circleSize, strokeColor, fillColor, Props.CroppedImageCopyId + "_ne_circle", "ResizeNE"));
        g.appendChild(SvgCreator.AddCircle(left, bottom, circleSize, strokeColor, fillColor, Props.CroppedImageCopyId + "_sw_circle", "ResizeNE"));
        g.appendChild(SvgCreator.AddCircle(right, bottom, circleSize, strokeColor, fillColor, Props.CroppedImageCopyId + "_se_circle", "ResizeNW"));
 
        PrivateSetTouchyEdgeHandlers(Props.CroppedImageCopyId + "_ne_circle", HandleTouchyCropResizeClosure(ResizeEnum.NE));
        PrivateSetTouchyEdgeHandlers(Props.CroppedImageCopyId + "_nw_circle", HandleTouchyCropResizeClosure(ResizeEnum.NW));
        PrivateSetTouchyEdgeHandlers(Props.CroppedImageCopyId + "_se_circle", HandleTouchyCropResizeClosure(ResizeEnum.SE));
        PrivateSetTouchyEdgeHandlers(Props.CroppedImageCopyId + "_sw_circle", HandleTouchyCropResizeClosure(ResizeEnum.SW));

        
        PrivateSetTouchyEdgeHandlers("ZoomCropAreaBox" , HandleTouchyCropMoveClosure());
        
    };

    function PrivateSetTouchyEdgeHandlers(id, touchyDragEvent)
    {
        $("#" + id).bind('touchy-drag', touchyDragEvent);
        //$("#" + id).data('touchy-drag').settings.msHoldThresh = 10;
    }

    function AddComputerSelectors(g)
    {
        var circleSize = 4;
        var strokeColor = "#AAA393";
        var fillColor = "#6285C7";
        var left = Props.CropLeft;
        var right = Props.CropWidth + Props.CropLeft;
        var top = Props.CropTop;
        var bottom = Props.CropHeight + Props.CropTop;

        g.appendChild(SvgCreator.AddCircle(left, top, circleSize, strokeColor, fillColor, Props.CroppedImageCopyId + "_nw_circle", "ResizeNW"));
        g.appendChild(SvgCreator.AddCircle(right, top, circleSize, strokeColor, fillColor, Props.CroppedImageCopyId + "_ne_circle", "ResizeNE"));
        g.appendChild(SvgCreator.AddCircle(left, bottom, circleSize, strokeColor, fillColor, Props.CroppedImageCopyId + "_sw_circle", "ResizeNE"));
        g.appendChild(SvgCreator.AddCircle(right, bottom, circleSize, strokeColor, fillColor, Props.CroppedImageCopyId + "_se_circle", "ResizeNW"));

        Private_SetEdgeHandlers(Props.CroppedImageCopyId + "_ne_circle", StartCropResizeClosure(ResizeEnum.NE));
        Private_SetEdgeHandlers(Props.CroppedImageCopyId + "_nw_circle", StartCropResizeClosure(ResizeEnum.NW));
        Private_SetEdgeHandlers(Props.CroppedImageCopyId + "_se_circle", StartCropResizeClosure(ResizeEnum.SE));
        Private_SetEdgeHandlers(Props.CroppedImageCopyId + "_sw_circle", StartCropResizeClosure(ResizeEnum.SW));
    };

    function Private_SetEdgeHandlers(id, mouseDownEvent)
    {
        $("#" + id).mousedown(mouseDownEvent);
    };

    function UpdateSelectors()
    {
            var cropAreaBox = $("#ZoomCropAreaBox");
            var nw_circle = $("#" + Props.CroppedImageCopyId + "_nw_circle");
            var ne_circle = $("#" + Props.CroppedImageCopyId + "_ne_circle");
            var sw_circle = $("#" + Props.CroppedImageCopyId + "_sw_circle");
            var se_circle = $("#" + Props.CroppedImageCopyId + "_se_circle");
 
            var left = Props.CropLeft;
            var right = Props.CropWidth + Props.CropLeft;
            var top = Props.CropTop;
            var bottom = Props.CropHeight + Props.CropTop;
            var middleX = (left + right) / 2;
            var middleY = (top + bottom) / 2;

            SvgCreator.UpdateRectangle(cropAreaBox, Props.CropLeft, Props.CropTop, Props.CropWidth, Props.CropHeight);

            SvgCreator.UpdateCircle(nw_circle, left, top);
            SvgCreator.UpdateCircle(ne_circle, right, top);
            SvgCreator.UpdateCircle(sw_circle, left, bottom);
            SvgCreator.UpdateCircle(se_circle, right, bottom);

    }

    function getCropClone(Props){
        return  {
            CropHeight  : Props.CropHeight ,
            CropTop     : Props.CropTop    ,
            CropWidth   : Props.CropWidth  ,
            CropLeft    : Props.CropLeft   
        }
    }

    //#endregion
    function UpdateCropBox(deltaX, deltaY)
    {
        var absX = Math.abs( deltaX );
        var absY = Math.abs( deltaY );

        if( absX >= absY ) deltaY = deltaX * Props.CropRatio ;
        else deltaX = deltaY / Props.CropRatio  ;

        var backupProp = getCropClone( Props );
 
        // handle X changes first
        switch (Props.CropResizeDirection)
        {
            case ResizeEnum.NE:
            {
                if( absX >= absY )
                {
                    backupProp.CropHeight += deltaY;
                    backupProp.CropTop -= deltaY;
                    backupProp.CropWidth += deltaX;
                } 
                else 
                {
                    backupProp.CropHeight -= deltaY;
                    backupProp.CropTop += deltaY;
                    backupProp.CropWidth -= deltaX;
                }
                break;
            }

            case ResizeEnum.NW:
            {
                backupProp.CropHeight -= deltaY;
                backupProp.CropTop    += deltaY;
                backupProp.CropWidth  -= deltaX;
                backupProp.CropLeft   += deltaX;

                break;
            }

            case ResizeEnum.SE:
            {
                backupProp.CropHeight += deltaY; 
                backupProp.CropWidth += deltaX;
                break;
            }

            case ResizeEnum.SW:
            {
                if( absX >= absY )
                {
                    backupProp.CropHeight -= deltaY;
                    backupProp.CropWidth -= deltaX;
                    backupProp.CropLeft  += deltaX;
                }
                else
                {
                    backupProp.CropHeight += deltaY;
                    backupProp.CropWidth += deltaX;
                    backupProp.CropLeft  -= deltaX;
                }
                break;
            } 
        }
 
        if( backupProp.CropTop >= Props.ViewArea.Y  && backupProp.CropTop  + backupProp.CropHeight < Props.ViewArea.Y + Props.ViewArea.Height &&
            backupProp.CropLeft >= Props.ViewArea.X && backupProp.CropLeft + backupProp.CropWidth < Props.ViewArea.X + Props.ViewArea.Width )
            { 
                Props.CropHeight    = backupProp.CropHeight;
                Props.CropTop       = backupProp.CropTop;
                Props.CropWidth     = backupProp.CropWidth;
                Props.CropLeft      = backupProp.CropLeft;
                
                UpdateSelectors();
            }

        
    };

    function MoveCropBox(deltaX, deltaY)
    { 
        
        if( Props.CropTop + deltaY >= Props.ViewArea.Y  && Props.CropTop + Props.CropHeight + deltaY < Props.ViewArea.Y + Props.ViewArea.Height )
            Props.CropTop += deltaY;

        if( Props.CropLeft + deltaX >= Props.ViewArea.X && Props.CropLeft + Props.CropWidth + deltaX < Props.ViewArea.X + Props.ViewArea.Width )
            Props.CropLeft += deltaX;
        
        UpdateSelectors();
    };

    function HandleTouchyCropResizeClosure(cropResizeDirection , CropPolygonPointSelectedID  )
    {
        return function (event, phase, $target, data)
        {
            if (phase != "move")
            {
                return;
            }
            Props.CropResizeDirection = cropResizeDirection;
            Props.CropPolygonPointSelectedID = CropPolygonPointSelectedID;

            if (Props.CropResizeDirection == null || Props.CropResizeDirection == undefined)
                return;

            var deltaX = data.movePoint.x - data.lastMovePoint.x;
            var deltaY = data.movePoint.y - data.lastMovePoint.y;

            UpdateCropBox(deltaX, deltaY);
        }
    };

    function HandleTouchyCropMoveClosure(cropResizeDirection )
    {
        return function (event, phase, $target, data)
        {
            if (phase != "move")
            {
                return;
            }

            var deltaX = data.movePoint.x - data.lastMovePoint.x;
            var deltaY = data.movePoint.y - data.lastMovePoint.y;
            
            MoveCropBox(deltaX, deltaY);
        }
    };

    function ConvertCoordinateToOriginal( evt ){
        var svg = document.getElementById("ZoomCropAreaSvg");
        Props.CalcPoint.x = evt.pageX; 
        Props.CalcPoint.y = evt.pageY;
        return Props.CalcPoint.matrixTransform( svg.getScreenCTM().inverse() );
        
    }

    function StartCropResizeClosure(cropResizeDirection , CropPolygonPointSelectedID )
    {
        return function (e)
        {
            var P = ConvertCoordinateToOriginal( e ) ;

            Props.ResizePageX = P.x;
            Props.ResizePageY = P.y;

            Props.CropAction = "Resize";
        
            Props.CropResizeDirection = cropResizeDirection;
            Props.CropPolygonPointSelectedID = CropPolygonPointSelectedID;

            e.stopPropagation();
        };
    };

    function StartCropAreaMoveClosure()
    {
        return function (e)
        {
            Props.CropAction = "Move";

            var P = ConvertCoordinateToOriginal( e );

            Props.ResizePageX = P.x;
            Props.ResizePageY = P.y;

            e.stopPropagation();
        };
    }

    function HandleCropMoveClosure()
    {
        return function (e)
        {
            if (Props.CropAction == "")
                return;
            var P = ConvertCoordinateToOriginal( e );

            deltaX = P.x - Props.ResizePageX;
            deltaY = P.y - Props.ResizePageY;

            Props.ResizePageX = P.x;
            Props.ResizePageY = P.y;

            if (Props.CropAction == "Resize")
                UpdateCropBox(deltaX, deltaY);

            else if (Props.CropAction == "Move")
                MoveCropBox(deltaX, deltaY);
        };
    };

    

    function StopCropResizeClosure()
    {
        return function ()
        {
            Props.CropAction = "";
        };
    };

    function GetImageBeingCropped()
    {
        var active = MyShapesState.Public_GetFirstSelectedShapeState();;

        if (active === null)
        {
            active = MyShapesState.Public_GetShapeStateById(Props.OriginalShapeId);
        }

        return active;
    };

 

    ZoomCropHelperObject.ShowCropDialog = function( activeShape )
    {
        // find cell and copy all object in that cell to this crop window
        var layoutParts = StoryboardContainer.GetAllLayoutParts(CellConfiguration);
        Props.CellPosition = StoryboardContainer._GetLayoutPartForShape(layoutParts, activeShape);
        Props.selectedShapeStates = Props.CellPosition ? StoryboardContainer.GetShapeStatesForCell( Props.CellPosition.Row , Props.CellPosition.Col ) : null;
        Props.CellId = MyIdGenerator.GenerateCellId (Props.CellPosition.Row , Props.CellPosition.Col);

        console.log(Props.selectedShapeStates);

        if( Props.CellId in StoryboardContainer.GlobalCellCropRatio )
             Props.PrevCellCropRatio = StoryboardContainer.GlobalCellCropRatio[ Props.CellId ];
        else Props.PrevCellCropRatio = { A1 : 0 , A2 : 1 , A3 : 0 , B1: 0 , B2 : 1 , B3 : 0 }; // initial full ratio
        
        if( !Props.selectedShapeStates || Props.selectedShapeStates.length <= 0 ) 
        { 
            return false;
        }

        MyPointers.Dialog_ZoomCropImage.one('shown.bs.modal', PrepareShapePostModalClosure(activeShape));

        var cropAreaSvg = $("#ZoomCropAreaSvg");
        cropAreaSvg.children().remove();
        MyPointers.Dialog_ZoomCropImage.modal();

        return true;
        
    };

    ZoomCropHelperObject.RemoveCrop = function ()
    {
        var active = GetImageBeingCropped();
        active.UseClipping = false;
        active.UpdateDrawing();
        MyPointers.Dialog_ZoomCropImage.modal('hide');

        UndoManager.register(undefined, UndoCrop, [active.Id, true, active.ClipX, active.ClipY, active.ClipWidth, active.ClipHeight , JSON.parse(JSON.stringify( active.CropPolygonPoint)) , active.CropType  ], '',
                             undefined, UndoCrop, [active.Id, active.UseClipping, active.ClipX, active.ClipY, active.ClipWidth, active.ClipHeight , JSON.parse(JSON.stringify( active.CropPolygonPoint)) , active.CropType], '');
    };

    ZoomCropHelperObject.CancelCrop = function ()
    {
        MyPointers.Dialog_ZoomCropImage.modal('hide');
        var active = GetImageBeingCropped();
        active.UpdateDrawing();
    };

    function GetNewPosition( P )
    {
        var newBoxPos = { x : Props.CropLeft - Props.CellPosition.X , y : Props.CropTop - Props.CellPosition.Y }; 
        return { x : ( P.x - Props.CropLeft  ) * Props.newScale + Props.CropLeft - newBoxPos.x , y : ( P.y - Props.CropTop ) * Props.newScale + Props.CropTop - newBoxPos.y  };
    }

    function MoveToCropArea( P  , CropArea , newScale )
    {
        var newBoxPos = { x : CropArea.X - Props.CellPosition.X , y : CropArea.Y - Props.CellPosition.Y };
        return { x : ( P.x - CropArea.X ) * newScale + CropArea.X - newBoxPos.x , 
                 y : ( P.y - CropArea.Y ) * newScale + CropArea.Y - newBoxPos.y  };
    }

    function rollbackMoveFromCropArea( P  , CropArea , newScale )
    {
        var newBoxPos = { x : CropArea.X - Props.CellPosition.X , y : CropArea.Y - Props.CellPosition.Y };
        return { x : ( P.x - CropArea.X + newBoxPos.x ) / newScale + CropArea.X ,
                 y : ( P.y - CropArea.Y + newBoxPos.y ) / newScale + CropArea.Y };
    }

    /**
     * We have to get new Cell retio from current Big Cropping View window
     * 
     */

    function getNewCellRatioFromViewArea()
    {
        var LX1 = Props.CropLeft - Props.ViewArea.X;
        var LX2 = Props.CropWidth ;
        var LX3 = Props.ViewArea.Width - LX1 - LX2 ;

        var LY1 = Props.CropTop - Props.ViewArea.Y;
        var LY2 = Props.CropHeight ;
        var LY3 = Props.ViewArea.Height - LY1 - LY2 ;

        return { A1 : LX1 / Props.ViewArea.Width , 
                 A2 : LX2 / Props.ViewArea.Width , 
                 A3 : LX3 / Props.ViewArea.Width , 
                 B1 : LY1 / Props.ViewArea.Height , 
                 B2 : LY2 / Props.ViewArea.Height , 
                 B3 : LY3 / Props.ViewArea.Height  };
    }
 
    
    ZoomCropHelperObject.UpdateCrop = function ( removeFlag )
    {
        if (MyBrowserProperties.IsMobile)
        {
            $.touchyOptions.useDelegation = true;
        }

        var active = GetImageBeingCropped();
        var newCellCropRatio = removeFlag ? { A1 : 0 , A2 : 1 , A3 : 0 , B1: 0 , B2 : 1 , B3 : 0 } : getNewCellRatioFromViewArea() ;
        var newCellCropRatioFactorA = newCellCropRatio.A1 + newCellCropRatio.A2 + newCellCropRatio.A3;
        var newCellCropRatioFactorB = newCellCropRatio.B1 + newCellCropRatio.B2 + newCellCropRatio.B3;

        StoryboardContainer.GlobalCellCropRatio[ Props.CellId ] = newCellCropRatio;

        Props.newScale = newCellCropRatioFactorA / newCellCropRatio.A2;

        /**
         * We have to calculate Crop area by the original size cell
         * newCellCropArea from the beginning viewpoint of the cell
         */

        var newCellCropArea = {
            X       : Props.CellPosition.X + newCellCropRatio.A1 * Props.CellPosition.Width  /  newCellCropRatioFactorA ,
            Y       : Props.CellPosition.Y + newCellCropRatio.B1 * Props.CellPosition.Height /  newCellCropRatioFactorB ,
            Width   : newCellCropRatio.A2 * Props.CellPosition.Width  /  newCellCropRatioFactorA  ,
            Height  : newCellCropRatio.B2 * Props.CellPosition.Height /  newCellCropRatioFactorB 
        };

        var undoParamList = [] , redoParamList = [];

       

        if( Props.selectedShapeStates )
            for (var i = 0; i < Props.selectedShapeStates[StoryboardPartTypeEnum.StoryboardCell].length; i++)
            {
                var activeShape = Props.selectedShapeStates[StoryboardPartTypeEnum.StoryboardCell][i];
                console.log(activeShape); 
                var undoParam = activeShape.getCropParam();
                // rollbackvar 
                Q = rollbackMoveFromCropArea( { x : activeShape.X , y : activeShape.Y } , Props.PrevCellCropArea , Props.PrevScale );
                P = MoveToCropArea          (   Q                                       , newCellCropArea        , Props.newScale  );

                activeShape.X = P.x;
                activeShape.Y = P.y;
 
                activeShape.ScaleX = activeShape.ScaleX * Props.newScale / Props.PrevScale ;
                activeShape.ScaleY = activeShape.ScaleY * Props.newScale / Props.PrevScale ;

                console.log( activeShape.ScaleX );
                console.log( activeShape.ScaleY );
                console.log( Props );
 
                var boxArea = activeShape.Private_GetSelectionBoxArea(0);
                var cen = { x : boxArea.CenterX , y : boxArea.CenterY };

                activeShape.UseClipping        = true;
                activeShape.CropType           = CropTypeEnum.Advanced;
                activeShape.CropPolygonPoint   = new Array();
                
                activeShape.CropPolygonPoint.push( activeShape.ConvertCoordinateToOrigin( { x : Props.CellPosition.X                            , y : Props.CellPosition.Y                             } , cen , true ) );
                activeShape.CropPolygonPoint.push( activeShape.ConvertCoordinateToOrigin( { x : Props.CellPosition.X                            , y : Props.CellPosition.Y + Props.CellPosition.Height } , cen , true ) );
                activeShape.CropPolygonPoint.push( activeShape.ConvertCoordinateToOrigin( { x : Props.CellPosition.X + Props.CellPosition.Width , y : Props.CellPosition.Y + Props.CellPosition.Height } , cen , true ) );
                activeShape.CropPolygonPoint.push( activeShape.ConvertCoordinateToOrigin( { x : Props.CellPosition.X + Props.CellPosition.Width , y : Props.CellPosition.Y                             } , cen , true ) );

                MyGroupAction.MinimizeAdvancedCropRegion( activeShape );
                CropHelper.UpdateRotatedObjectPosition( activeShape );
                
                var redoParam = activeShape.getCropParam();
                
                activeShape.UpdateDrawing();

                undoParamList.push( undoParam );
                redoParamList.push( redoParam );
            }

        UndoManager.register(undefined, UndoZoomCrop, [ undoParamList , Props.CellId , Props.PrevCellCropRatio ] , '' , 
                             undefined, UndoZoomCrop, [ redoParamList , Props.CellId , newCellCropRatio        ], '');
        MyPointers.Dialog_ZoomCropImage.modal('hide');

        var allshapeStates = MyShapesState.Public_GetAllShapeStates();

        console.log( StoryboardContainer.GlobalCellCropRatio );
    };
 
    return ZoomCropHelperObject;
}();

function UndoZoomCrop( ParamList, CellId , CellCropRatio )
{
    var i;
    var layoutParts = StoryboardContainer.GetAllLayoutParts(CellConfiguration);
     
    StoryboardContainer.GlobalCellCropRatio[ CellId ] = CellCropRatio;

    for( i = 0 ; i < ParamList.length; i++ )
    {
        var activeShape = MyShapesState.Public_GetShapeStateById( ParamList[i].Id );
        activeShape.setCropParam( ParamList[i] );
        activeShape.UpdateDrawing();
    }
}
