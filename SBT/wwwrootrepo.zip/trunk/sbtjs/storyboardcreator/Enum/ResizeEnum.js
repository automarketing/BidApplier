﻿ResizeEnum = {
    NE: "NE",
    SE: "SE",
    NW: "NW",
    SW: "SW",
    N: "N",
    S: "S",
    E: "E",
    W: "W",
    NSEW: "NSEW",
};

