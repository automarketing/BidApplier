﻿// This is the hidden meta data in svg files!

this.SbtDataEnum =
{
    Attribute_TiltOption_Title: "Title",
    Attribute_TiltOption_Degree: "Degree",

    Attribute_TiltPose_Title: "Title",
    Attribute_TiltPose_DefaultTilt: "DefaultTilt",
    Attribute_TiltPose_TiltableId: "TiltableId",
    Attribute_TiltPose_Tiltable2Id: "Tiltable2Id",
    Attribute_TiltPose_PivotId: "PivotId",
    Attribute_TiltPose_ClearId: "ClearId",

    Attribute_SwapOption_Title: "Title",
    Attribute_SwapOption_SwapId: "SwapId",

    Attribute_SwapPose_Title: "Title",
    Attribute_SwapPose_DefaultId: "DefaultSwapId",
    Attribute_SwapPose_AppendToId: "AppendToId",

    Attribute_LibrarySwapOption_Title: "Title",
    Attribute_LibrarySwapOption_SwapId: "SwapLibraryId",

    Attribute_LibrarySwapPose_Title: "Title",
    Attribute_LibrarySwapPose_DefaultId: "DefaultLibrarySwapId",
    Attribute_LibrarySwapPose_StartPointId: "StartPointId",
    Attribute_LibrarySwapPose_AppendToId: "AppendToId",

    Attribute_SmartSceneItemOption_Title: "Title",
    //Attribute_SmartSceneItemOption_Name: "Name",
    Attribute_SmartSceneItemOption_TurnOn: "TurnOn",
    Attribute_SmartSceneItemOption_TurnOff: "TurnOff",
    Attribute_SmartSceneItemOption_Default: "Default",

    Attribute_SmartSceneItemOptionColor_Region: "Region",
    Attribute_SmartSceneItemOptionColor_ReplaceColor: "ReplaceColor",

    Attribute_Pose_Type: "Type",

    PoseType_Swap: "Swap",
    PoseType_Tilt: "Tilt",
    PoseType_LibrarySwap: "LibrarySwap",

    Id_SwapOption_Middle: "_poseswap_",
    Id_Swap_Middle: "_SWAP_",
    Id_GlobalLibrary_Middle: "_Library_",
    Id_Storage: "storage",
    Id_DisplayOption: "DisplayOption",


    GlobalLibraryId: "gsl",
    //has to be same name as cache svg, and HAS to have gsl_
    GlobalLibraryFacesFrontId: "gsl_faces_front",
    GlobalLibraryFacesSideId: "gsl_faces_side",

    MetaData_Posable: "posable",
    MetaData_Poses: "pose",
    MetaData_Position: "position",

    MetaData_SmartScene: "smartscene",
    MetaData_SmartSceneItem: "smartsceneitem",
    MetaData_SmartSceneItemOption: "smartsceneitemoption",
    MetaData_SmartSceneItemOptionColor: "smartsceneitemoptioncolor",

    //MetaData_Springable_Anchors: "anchors",
    MetaData_Springable_Anchorset: "anchorset",
    //MetaData_Springable_Spring: "springs",
    MetaData_Springable_SpringSet: "springset",
    MetaData_Springable_Attribute_Side: "side",
    MetaData_Springable_Attribute_Direction: "direction",
    MetaData_Springable_Attribute_Groups: "groups",

    AttributeGlobalImageId: "sbt_image_id",


};
