<?php

function back_main_tab( $select )
{
    $p[$select] = 'nav-tab-active';
?>    

    	<h2 class="nav-tab-wrapper">
    		<a href="admin.php?page=total_activity_main" class="nav-tab <?php echo $p[0]; ?>">
    		  Total Activity
    		</a>
    		<a href="admin.php?page=company_history" class="nav-tab  <?php echo $p[1]; ?>">
    		  Company Information
    		</a>
            <a href="admin.php?page=MostVisistPage_history" class="nav-tab  <?php echo $p[2]; ?>">
              Most visited Pages
            </a>
            <a href="admin.php?page=ActiveCompany_history" class="nav-tab  <?php echo $p[3]; ?>">
              Most Active Companies
            </a>
        </h2>
<?php
}
?>