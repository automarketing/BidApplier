﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using StoryboardAnalysis.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoryboardAnalysis.DB
{
    class StoryboardProcess : Storyboard
    {
        public List<BsonDocument> GetStoryboardImages(int userStoryboardId)
        {
            // Find by userStoryboardId
            return _FindStoryBoardImage("[{ \"user_storyboard_id\": " + userStoryboardId.ToString() +" }]" );
        }

        public async Task<bool> DeleteStoryboardImagesAsync(int userStoryboardId)
        {
            // Find by userStoryboardId
            return await _RemoveStoryBoardImage("[{ \"user_storyboard_id\": " + userStoryboardId.ToString() + " }]");
        }

        public async void CheckAndAddMultipleStoryboardImage(int userStoryboardId, string JsonData)
        {
            BsonArray T = BsonSerializer.Deserialize<BsonArray>(JsonData);
            BsonArray newImageDataList = new BsonArray();

            foreach (BsonValue nImage in T)
            {
                if (_IsValidDataStoryBoardImage(nImage))
                    newImageDataList.Add(nImage);
            }


            List<BsonDocument> currentStoryboardImages = GetStoryboardImages(userStoryboardId);
            foreach (BsonDocument usi in currentStoryboardImages)
            {
                bool bFlag = false;
                foreach (BsonValue nImage in newImageDataList)
                    if (nImage["image_type_id"] == usi["image_type_id"] && nImage["int_foreign_key_id"] == usi["int_foreign_key_id"]
                        && nImage["string_foreign_key_id"] == usi["string_foreign_key_id"])
                    {
                        bFlag = true;
                        newImageDataList.Remove(nImage);
                        if (nImage["image_count"] != usi["image_count"])
                        {
                            await _UpdateStoryBoardImage(
                                "[ { \"image_type_id\":\"" + nImage["image_type_id"].ToString() + "\" } ," +
                                "  { \"int_foreign_key_id\":\"" + nImage["int_foreign_key_id"].ToString() + "\" } ," +
                                "  { \"string_foreign_key_id\":\"" + nImage["string_foreign_key_id"].ToString() + "\" } ]"
                                , "[{ \"image_count\":\"" + nImage["image_count"].ToString() + "\" } ]");
                        }
                        break;
                    }
                if (!bFlag)
                {
                    await _RemoveStoryBoardImage("[ { \"image_type_id\":\"" + usi["image_type_id"].ToString() + "\" } ," +
                                "  { \"int_foreign_key_id\":\"" + usi["int_foreign_key_id"].ToString() + "\" } ," +
                                "  { \"string_foreign_key_id\":\"" + usi["string_foreign_key_id"].ToString() + "\" } ]");
                }
            }

            if( newImageDataList.Count >  0 )
                await _AddMultipleStoryBoardImage(newImageDataList.ToJson());

        }
        public List<BsonDocument> GetStoryboardsWithSpecificImage(int image_type_id, int foreign_key_id, int pageNumber, int pageSize)
        {
            return _FindStoryBoardImage("[{ \"image_type_id\": " + image_type_id.ToString() + " } , " +
                "{ \"foreign_key_id\": " + foreign_key_id.ToString() + " } ]" , pageNumber - 1 , pageSize );
        }

        public List<BsonDocument> GetStoryboardImageUsageAll(int minStoryboardId, ImageTypesEnum imageType)
        {
            return _GetStoryboardImageUsageAll( minStoryboardId , imageType );
        }

    }
}
