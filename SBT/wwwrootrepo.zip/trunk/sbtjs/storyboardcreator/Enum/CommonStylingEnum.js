﻿//http://www.colorcombos.com/color-schemes/408/ColorCombo408.html
this.CommonStylingEnum =
       {
           ShapeSelector_HotSpot_Corner_Stroke: "#AAA393",
           ShapeSelector_HotSpot_Corner_Fill: "#6285C7",
           ShapeSelector_HotSpot_Corner_CircleSize: 5,

           ShapeSelector_HotSpot_Side_Stroke: "#6285C7",
           ShapeSelector_HotSpot_Side_Fill: "#AAA393",
           ShapeSelector_HotSpot_Side_CircleSize: 5,

           ShapeSelector_RotateBar_Css: "RotateBar",

           ShapeSelector_ResizeHotSpot_NW_Css: "ResizeNW",
           ShapeSelector_ResizeHotSpot_NE_Css: "ResizeNE",
           ShapeSelector_ResizeHotSpot_V_Css: "ResizeV",
           ShapeSelector_ResizeHotSpot_H_Css: "ResizeH",
           
       };