﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoryboardAnalysis.Models
{
    public class UserStoryboardImage
    {
        public int user_storyboard_image_id { get; set; }
        public int user_storyboard_id { get; set; }
        public int image_type_id { get; set; }
        public int int_foreign_key_id { get; set; }
        public string string_foreign_key_id { get; set; }
        public int image_count { get; set; }
    }
}
