﻿this.SvgPartsEnum =
       {
           ShapeId: "sbt_",
           Natural: "_natural",
           Defs: "_defs",
           ClipPath: "_clipPath",
           ClipRect: "_clipRect",
           ClipPolygon: "_clipPolygon",
           ClipEllipse: "_clipEllipse",
           Scale: "_scale",
           CropGroup: "_cropGroup",
           SvgImage: "_svgImage",
           ImaginaryBox: "_imaginary_box",
           SelectionBox: "_selection_box",
           SelectionBoxRectangle: "_selection_box_rect",
           RotateCircle: "_rotate_circle",
           RotateCircleBar: "_rotate_circle_bar",
           RotateCircleGroup: "_rotate_circle_group",

           Selector_NW: "_nw_circle",
           Selector_NE: "_ne_circle",
           Selector_SW: "_sw_circle",
           Selector_SE: "_se_circle",

           Selector_W: "_w_circle",
           Selector_E: "_e_circle",
           Selector_N: "_n_circle",
           Selector_S: "_s_circle",

           Imaginary_NE: "_imaginary_ne",
           Imaginary_NW: "_imaginary_nw",
           Imaginary_SE: "_imaginary_se",
           Imaginary_SW: "_imaginary_sw",

           
           
           

       };