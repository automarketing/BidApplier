﻿SbtConstants = {
    SelectionAreaStrokeColor: "#526C85",
    SelectionAreaFillColor: "#D0E8F4",
    SelectionAreaStrokeDash: "4.4",
    SelectionAreaOpacity: .75,
};
