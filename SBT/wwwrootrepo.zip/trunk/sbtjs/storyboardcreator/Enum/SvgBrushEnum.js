﻿SvgBrushEnum =
{
    RemoveColor : 1 ,
    Silhouette  : 2 ,
    Marker      : 3 ,
    Pen         : 4 ,
    Pencil      : 5 
};