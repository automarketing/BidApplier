﻿var CellSorterHelper = function ()
{
    var CellSorterHelperObject = new Object();

    CellSorterHelperObject.ChangeCellOrder = function (reorderList)
    {
        for (var i = 0; i < reorderList.length; i++)
        {
            var cellOrder = reorderList[i];

            var shapeStates = StoryboardContainer.GetShapeStatesForCell(cellOrder.oldCol, cellOrder.oldRow);

            for(var j=0; j<shapeStates.length; j++)
            {

            }
        }
    };

    return CellSorterHelperObject
}();