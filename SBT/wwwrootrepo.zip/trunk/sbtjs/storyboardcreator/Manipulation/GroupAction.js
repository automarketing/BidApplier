﻿///  <reference path="../SvgManip.js" />

function GroupAction()
{
    var CurrentGroupId = 1;

    this.MakeGroup = function(e)
    {
        var selectedShapeStates = MyShapesState.Public_GetAllSelectedShapeStates( true );

        if( selectedShapeStates.length <= 1 ) // group with 2 more than objects
        return;

        MyGroupAction.MakeGroupFromSelectedObjects( selectedShapeStates );
    }

  

    this.MakeGroupFromSelectedObjects =  function( selectedShapeStates , pos_update )
    {
        var undoArray = new Array();
        var redoArray = new Array();

        var clones = new Array();
        var i;
        
        var topmost = null;
        var leftmost = null;
        var bottommost = null;
        var rightmost = null;

        var LastSVGId = FindTopMostSVG_in_SelectedGroup( selectedShapeStates );
        var LastTopShape = $( "#" + LastSVGId ).next();
 
        for ( i = 0; i < selectedShapeStates.length; i++)
        {
            var box = selectedShapeStates[i].Public_GetImaginaryOuterBox();

            if( i == 0 || topmost   > box.Top ) topmost = box.Top;
            if( i == 0 || leftmost  > box.Left ) leftmost = box.Left;
            if( i == 0 || rightmost < box.Right ) rightmost = box.Right;
            if( i == 0 || bottommost < box.Bottom ) bottommost = box.Bottom; 
        }
 
 
        
        var viewW = rightmost - leftmost;
        var viewH = bottommost - topmost;
        var svg = SvgCreator.CreateBlankSvg(viewW , viewH);
        svg.setAttribute( "viewBox" , 0 + " " +0  + " " + viewW  + " " + viewH  );
        var g = SvgCreator.CreateSvgGroup("natural"+CurrentGroupId);
        g.appendChild(svg);
        var svg_ = $(svg);
        
        for( var i = 0 ; i < selectedShapeStates.length ; i++ )
            selectedShapeStates[i].nextShapeId = $( "#" + selectedShapeStates[i].Id ).next().attr("id");

        AttachChildrenShapesToParent( selectedShapeStates , svg_ , leftmost , topmost );
        
        
        var newShape = AddSvg.AddSvgToStoryboard(g, 0, 0, true);
        LastTopShape.before(newShape);
        var newShapeState = MyShapesState.Public_GetShapeStateByShape(newShape);
 
        newShapeState.X              = leftmost;
        newShapeState.Y              = topmost;
        newShapeState.ScaleX         = 1;
        newShapeState.ScaleY         = 1;
        newShapeState.NaturalOffsetX = 0;
        newShapeState.NaturalOffsetY = 0;
        newShapeState.UseClipping    = true;
        newShapeState.ClipX          = 0;
        newShapeState.ClipY          = 0;
        newShapeState.ClipWidth      = viewW;
        newShapeState.ClipHeight     = viewH;

        newShapeState.isGroupObject = true;

        for( i = 0 ; i < selectedShapeStates.length ; i++ )
        {
            newShapeState.groupShapeStates.push( selectedShapeStates[i] );
        }

        MyShapesState.Public_ClearAllSelectedShapes();
        HideControlsMenu();
        MyShapesState.Public_SelectShape(newShape);
        UpdateActiveDrawing();

        UndoManager.register(
            undefined , DisassembleShapes, [{ childShapeStates : selectedShapeStates , parentShapeState: newShapeState , parentShape : newShape                          }] , '' , 
            undefined , AssembleShapes,    [{ childShapeStates : selectedShapeStates , parentShapeState: newShapeState , parentShape : newShape , LastSVGId : LastSVGId  }] , ''  );
        
        return newShapeState;
    };
 
    
    ///////////////// Related with Ungroup ////////////////////

    this.ApplyParentStateToChild = function( shapeState , Param )
    {
        /*
            Calculate the distance between center point of Parent Box and Children box
            Move and Rotate children around parent
            Use scaleX and scaleY for children element
         */

        var boxArea = shapeState.Private_GetSelectionBoxArea(0);
        var cen     = { x : Param.CenterX , y : Param.CenterY };
        var P = { x: shapeState.X * Param.Sx , y :shapeState.Y * Param.Sy };
        P = { x: P.x + boxArea.CenterX * Param.Sx - cen.x , y: P.y + boxArea.CenterY * Param.Sy - cen.y };
        P = { x: P.x * Math.cos( Param.Angle * Math.PI / 180.0 ) - P.y * Math.sin( Param.Angle * Math.PI / 180.0 ) ,
              y: P.x * Math.sin( Param.Angle * Math.PI / 180.0 ) + P.y * Math.cos( Param.Angle * Math.PI / 180.0 ) };
        P = { x: P.x - boxArea.CenterX * Param.Sx + cen.x , y: P.y - boxArea.CenterY * Param.Sy + cen.y };

        // if( shapeState.FlipHorizontal )
        //     P.x -= cen.x * 2 ; // boxarea.width
        // if( shapeState.FlipVertical )
        //     P.y -= cen.y * 2 ; // boxarea.height

        shapeState.X = P.x + Param.fX;
        shapeState.Y = P.y + Param.fY;
    }

    this.ApplyParentClippingToChild = function( cSS , pSS , cenP )
    {
        if( !pSS.UseClipping ) return;
        if( pSS.CropType != CropTypeEnum.Advanced ) return;
 
        // from Parent co-ordinate to child co-ordinate  
        var boxAreaC = cSS.Private_GetSelectionBoxArea(0);
 
        var cenC = { x : boxAreaC.CenterX , y : boxAreaC.CenterY };

        cSS.CropPolygonPoint = [];
        
        var PosLeft = null , PosTop = null , PosBottom = null , PosRight = null ;

        for( i = 0 ; i < pSS.CropPolygonPoint.length ; i++ )
        {
            var P = { x : pSS.CropPolygonPoint[i].x , y : pSS.CropPolygonPoint[i].y };
             
            P = pSS.ConvertCoordinateToStage ( P , cenP , true );
            P = cSS.ConvertCoordinateToOrigin( P , cenC , true );
            cSS.CropPolygonPoint.push( P ); 
        }

        cSS.UseClipping= pSS.UseClipping;
        cSS.CropType   = pSS.CropType;
        cSS.Public_update_ClipRegionByAdvancedCrop();
    }

    this.MinimizeAdvancedCropRegion = function( shapeState )
    {
        if( !shapeState.UseClipping || shapeState.CropType != CropTypeEnum.Advanced ) 
            return false;
        
        var convexHull = new ConvexHullGrahamScan();
        var i;
        
        var scaleElement = shapeState.Private_GetElement(SvgPartsEnum.Scale);
        var scaleBb = scaleElement.getBBox();
        var OBox = { Left : scaleBb.x , Right : scaleBb.x + scaleBb.width , Top : scaleBb.y , Bottom : scaleBb.y + scaleBb.height };
        


        if( checkPolygonInnerPoint( { x : OBox.Left   , y: OBox.Top    } , shapeState.CropPolygonPoint ) ) convexHull.addPoint( OBox.Left   ,  OBox.Top     );
        if( checkPolygonInnerPoint( { x : OBox.Left   , y: OBox.Bottom } , shapeState.CropPolygonPoint ) ) convexHull.addPoint( OBox.Left   ,  OBox.Bottom  );
        if( checkPolygonInnerPoint( { x : OBox.Right  , y: OBox.Top    } , shapeState.CropPolygonPoint ) ) convexHull.addPoint( OBox.Right  ,  OBox.Top     );
        if( checkPolygonInnerPoint( { x : OBox.Right  , y: OBox.Bottom } , shapeState.CropPolygonPoint ) ) convexHull.addPoint( OBox.Right  ,  OBox.Bottom  );
 
        for( i = 0 ; i < shapeState.CropPolygonPoint.length ; i++ )
        {
            var A = shapeState.CropPolygonPoint[ i ];
            var B = shapeState.CropPolygonPoint[ ( i + 1 ) % shapeState.CropPolygonPoint.length ];
            var I = new Array();

            I[0] = checkLineIntersection( A.x , A.y , B.x , B.y , OBox.Left  , OBox.Top       , OBox.Left  , OBox.Bottom );
            I[1] = checkLineIntersection( A.x , A.y , B.x , B.y , OBox.Left  , OBox.Bottom    , OBox.Right , OBox.Bottom );
            I[2] = checkLineIntersection( A.x , A.y , B.x , B.y , OBox.Right , OBox.Bottom    , OBox.Right , OBox.Top );
            I[3] = checkLineIntersection( A.x , A.y , B.x , B.y , OBox.Right , OBox.Top       , OBox.Left  , OBox.Top );

            

            if( checkRectangleInnerPoint( A, OBox ) )
                convexHull.addPoint( A.x , A.y );

            for( var j = 0 ; j < 4 ;j++ )
            {
                if( I[j].intersect )
                    convexHull.addPoint( I[j].x, I[j].y );
            }
        } 
        
        var hullPoints = convexHull.getHull();

        if( hullPoints.length >= 3 ) 
        {
            shapeState.CropPolygonPoint = new Array();
            for(i = 0 ; i < hullPoints.length ; i++)
                shapeState.CropPolygonPoint.push( { x : hullPoints[i].x , y : hullPoints[i].y } );
            shapeState.Public_update_ClipRegionByAdvancedCrop();
            shapeState.CropPolygonPointJson = JSON.stringify( shapeState.CropPolygonPoint );
            
            return true;
        } else {
            shapeState.CropType   = CropTypeEnum.Standard;
            shapeState.ClipWidth  = 0 ;
            shapeState.ClipHeight = 0 ;
            shapeState.X = -1000;
            return false;
        }
    }

    this.UnGroup = function ( e , selectedShapeState  )
    {
        if( !selectedShapeState || selectedShapeState == undefined )
            selectedShapeState = MyShapesState.Public_GetFirstSelectedShapeState();
         
        if( !selectedShapeState.isGroupObject )
            return;

        /**
         * pDos 2018.1.6.
         * Temporary Remove Parent Flip  
         */

        selectedShapeState.FlipHorizontal = false;
        selectedShapeState.FlipVertical   = false;

        var ParentUndoParam = selectedShapeState.getCropParam();
        
        selectedShapeState.Public_convert_RectangleToAdvanced();

        var LastSVGId = $("#" + selectedShapeState.Id).next().attr("id");

        var boxArea = selectedShapeState.Private_GetSelectionBoxArea(0);
        var undoParamList = [] , redoParamList = [];
        var P = {
                CenterX             : boxArea.CenterX , 
                CenterY             : boxArea.CenterY , 
                fX                  : selectedShapeState.X ,
                fY                  : selectedShapeState.Y ,
                Sx                  : selectedShapeState.ScaleX ,
                Sy                  : selectedShapeState.ScaleY ,
                flipH               : selectedShapeState.FlipHorizontal ,
                flipV               : selectedShapeState.FlipVertical ,
                Angle               : selectedShapeState.Angle ,
                FilterColorMode     : selectedShapeState.FilterColorMode , 
                FilterBrushMode     : selectedShapeState.FilterBrushMode
            };

        var cen = { x : boxArea.CenterX , y : boxArea.CenterY };
        var i;
            
        DetachChildrenShapesFromParent( selectedShapeState , true );

        MyShapesState.Public_ClearAllSelectedShapes();
        HideControlsMenu();

        for( i = 0 ; i < selectedShapeState.groupShapeStates.length ; i++ )
        {
            var undoParam = selectedShapeState.groupShapeStates[i].getCropParam();

            MyGroupAction.ApplyParentStateToChild( selectedShapeState.groupShapeStates[i] , P );
            
            selectedShapeState.groupShapeStates[i].Angle  += P.Angle;
            selectedShapeState.groupShapeStates[i].ScaleX *= P.Sx;
            selectedShapeState.groupShapeStates[i].ScaleY *= P.Sy;
            selectedShapeState.groupShapeStates[i].opacity *= selectedShapeState.opacity;
            if( P.FilterColorMode ) selectedShapeState.groupShapeStates[i].FilterColorMode  = P.FilterColorMode;
            if( P.FilterBrushMode ) selectedShapeState.groupShapeStates[i].FilterBrushMode  = P.FilterBrushMode;
                
            selectedShapeState.groupShapeStates[i].UpdateDrawing();

            if( selectedShapeState.FlipVertical     ) selectedShapeState.groupShapeStates[i].FlipVertical   = !selectedShapeState.groupShapeStates[i].FlipVertical;
            if( selectedShapeState.FlipHorizontal   ) selectedShapeState.groupShapeStates[i].FlipHorizontal = !selectedShapeState.groupShapeStates[i].FlipHorizontal;

            MyShapesState.Public_SelectShape( $("#"+selectedShapeState.groupShapeStates[i].Id) );
            MyGroupAction.ApplyParentClippingToChild( selectedShapeState.groupShapeStates[i] , selectedShapeState , cen );
            MyGroupAction.MinimizeAdvancedCropRegion( selectedShapeState.groupShapeStates[i] );

            var redoParam = selectedShapeState.groupShapeStates[i].getCropParam();

            undoParamList.push( undoParam );
            redoParamList.push( redoParam );
        }

        var ParentRedoParam = selectedShapeState.getCropParam();

        var selectedShape = $( "#" + selectedShapeState.Id).detach();
        MyShapesState.Public_RemoveShapeStateById(selectedShapeState.Id);
        UpdateActiveDrawing();

        UndoManager.register(
            undefined , AssembleWithOriginalChildren    , [{ childShapeStates : selectedShapeState.groupShapeStates , parentShapeState: selectedShapeState , parentShape : selectedShape , ChildParams : undoParamList , ParentParam : ParentUndoParam ,LastSVGId : LastSVGId  }] , '' , 
            undefined , DisassembleWithOriginalChildren , [{ childShapeStates : selectedShapeState.groupShapeStates , parentShapeState: selectedShapeState , parentShape : selectedShape , ChildParams : redoParamList , ParentParam : ParentRedoParam                         }] , ''   );

    };

    this.CheckGroupObject = function()
    {
        var selectedShapeState = MyShapesState.Public_GetFirstSelectedShapeState();      
        return selectedShapeState.isGroupObject ;
    };
}

/////////////////////////////////////////////////////// Group Related ///////////////////////////////////////////// 
 
function DetachChildrenShapesFromParent( parentShapeState , ungroupFlag )
{
    var i;
    var parentNextObject = $( "#" + parentShapeState.Id ).next();
    var Container        = $( "#" + parentShapeState.Id + "_svgImage" );
 
    Container.children('g').each(function () {
        var id = this.getAttribute( "id" ); 
        var detached = $(this).detach();
        detached.on("mousedown" ,ShapeSelected );
        detached.on("mouseup" ,HandleMouseExit );
        parentNextObject.before(detached);
    });

    if( !ungroupFlag )
    {
        /**
         * Ungroup Action shouldn't find original object when detached.
         * After grouping, the neighbourhood relations ( parentShapeState.groupShapeStates[j].nextShapeId ) are destroyed
         * Just GetSvgTop() based insert is best approach for this
         * 
         */

        var j;
        for( j = parentShapeState.groupShapeStates.length - 1 ; j >= 0 ; j-- ) 
        {
            var shape = $( "#" + parentShapeState.groupShapeStates[j].Id );
            if( $( "#" + parentShapeState.groupShapeStates[j].nextShapeId ).length )
            {
                // neighbour object could be deleted when user delete it after grouping ,upgroup is different with undo-group
                $( "#" + parentShapeState.groupShapeStates[j].nextShapeId ).before(shape);
            }
        }
    }

    for( i = 0 ; i < parentShapeState.groupShapeStates.length ; i++ )
    { 
        MyShapesState.Public_SetShapeState( parentShapeState.groupShapeStates[i].Id , parentShapeState.groupShapeStates[i] );
    }

}

function DisassembleShapes()
{
    if( arguments.length < 1 ) return;
    
    var childShapeStates = arguments[0].childShapeStates;
    var parentShape      = arguments[0].parentShape;
    var parentShapeState = arguments[0].parentShapeState;
    var ungroupFlag      = arguments[1];
    var i;

    DetachChildrenShapesFromParent( parentShapeState , ungroupFlag );

    MyShapesState.Public_ClearAllSelectedShapes();

    for( i = 0 ; i < childShapeStates.length ; i++ )
    {
        var shapeState = childShapeStates[i];
 
        shapeState.X += parentShapeState.X ;
        shapeState.Y += parentShapeState.Y ; 

        MyShapesState.Public_SelectShape( $("#" + shapeState.Id) );
        shapeState.UpdateDrawing();
    }

    $( "#" + parentShapeState.Id).remove();
    MyShapesState.Public_RemoveShapeStateById(parentShapeState.Id);
}

function AttachChildrenShapesToParent( childShapeStates , Container , OffsetX , OffsetY , ungroupFlag )
{
    var i;
    for ( i = 0; i < childShapeStates.length; i++)
    {
        var shapeState = childShapeStates[i];

        if( !ungroupFlag )
        {
            shapeState.X -= OffsetX ;
            shapeState.Y -= OffsetY ;
        }

        shapeState.UpdateDrawing();

        var shape = $( "#" + shapeState.Id );
        shape.find("[id$='selection_box']").remove(); 
        shape.off("mousedown");
        shape.off("mouseup");
        Container.append( shape );

        MyShapesState.Public_RemoveShapeStateById(shapeState.Id);
    }
}

/*
 * ungroupFlag : Ungroup action's [Undo,Redo] is different with Group action's one
 * But we are sharing same function AssembleShapes and DisassembleShapes in both action
 * This flag tell the difference between Ungroup Action and Group Action
 */

function AssembleShapes() 
{
    // different with group action , but using previous built parameters

    if( arguments.length < 1 ) return;
    
    var childShapeStates = arguments[0].childShapeStates;
    var parentShape      = arguments[0].parentShape;
    var parentShapeState = arguments[0].parentShapeState;
    var LastSVGId        = arguments[0].LastSVGId;
    var ungroupFlag      = arguments[1];

    $("#"+LastSVGId).before( parentShape );
    var Container = $( "#" + parentShapeState.Id + "_svgImage");

    AttachChildrenShapesToParent( childShapeStates , Container , parentShapeState.X , parentShapeState.Y , ungroupFlag  );

    parentShape = $( "#" + parentShapeState.Id );
    parentShape.on("mousedown" ,ShapeSelected );
    parentShape.on("mouseup" ,HandleMouseExit );

    MyShapesState.Public_ClearAllSelectedShapes();
    MyShapesState.Public_SetShapeState( parentShapeState.Id , parentShapeState );
    MyShapesState.Public_SelectShape( $( "#" + parentShapeState.Id ) );
    parentShapeState.UpdateDrawing();
}


/////////////////////////////////////////////////////// UnGroup Related  ///////////////////////////////////////////// 

function AssembleWithOriginalChildren()
{
    if( arguments.length < 1 ) return;

    var childShapeStates = arguments[0].childShapeStates;
    var parentShape      = arguments[0].parentShape;
    var parentShapeState = arguments[0].parentShapeState;
    var ChildParams      = arguments[0].ChildParams;
    var ParentParam      = arguments[0].ParentParam;
    var i;
 
    for( i = 0 ; i < childShapeStates.length; i++ )
    { 
        childShapeStates[i].setCropParam( ChildParams[i] );
    }

    AssembleShapes( arguments[0] , true );
    parentShapeState.setCropParam( ParentParam );
    parentShapeState.UpdateDrawing();

}

function DisassembleWithOriginalChildren()
{
    if( arguments.length < 1 ) return;

    var childShapeStates = arguments[0].childShapeStates;
    var parentShape      = arguments[0].parentShape;
    var parentShapeState = arguments[0].parentShapeState;
    var ChildParams      = arguments[0].ChildParams;
    var ParentParam      = arguments[0].ParentParam;
    var i;

    parentShapeState.setCropParam( ParentParam );
    DisassembleShapes( arguments[0] , true );

    for( i = 0 ; i < childShapeStates.length; i++ )
    {
        childShapeStates[i].setCropParam( ChildParams[i] );
        childShapeStates[i].UpdateDrawing();
    }

}