﻿var MultiTextableHelper = function ()
{
    var MultiTextableObject = new Object();
    var Props = new Object();
    
    Props.MultiTextImageCopyId = "MultiTextableImageCopy";
    Props.OriginalShape;
    MultiTextableObject.Props = Props;

    var mtShape = null;

    
    function PrepareShapePostModal(activeShape)
    { 
        // init creation
        Props.OriginalShape = activeShape;
        
        //pDos 2017  , Make mtShape : multi textable shape and attach it to clone ID
        var multiTextableSvg = $("#multiTextableSvg"); 
        var clone = $("#" + activeShape.Id).clone();

        StoryboardContainer.UpdateGradientIds(clone);

        clone.attr("id", Props.MultiTextImageCopyId);
        clone.attr("class", "");
        // Remove selection box and clip-path defs if present
        clone.find("[id$='selection_box'], [id$='_defs']").remove();
        clone.find("[id^='"+Props.OriginalShape.Id+"_text']").remove();
        // If there is a crop-group, reset it
        clone.find("[id$='cropGroup']").removeAttr("clip-path").attr("id", Props.MultiTextImageCopyId + "_cropGroup");
        // Translate the clone by 20px in both directions
        var scale = clone.find("[id$='_scale']").attr("id", Props.MultiTextImageCopyId + "_scale");
        clone.find("[id$='_natural']").attr("id", Props.MultiTextImageCopyId + "_natural");

        multiTextableSvg.children().remove();
        multiTextableSvg.append(clone);

        var clonebox = GetGlobalById(Props.MultiTextImageCopyId).getBBox();    
        multiTextableSvg.attr("width", clonebox.width+24);
        multiTextableSvg.attr("height", clonebox.height+24);

        if( !mtShape )
            mtShape = new SvgState(Props.MultiTextImageCopyId); 

        // error fix of init 
        var IsFirstTextQuillNull = activeShape.TextState.D[ activeShape.TextState.CurrentId ]._QuillDeltas ;

        mtShape.Id = Props.MultiTextImageCopyId;
        mtShape.NaturalOffsetX = activeShape.NaturalOffsetX;
        mtShape.NaturalOffsetY = activeShape.NaturalOffsetY;        
        mtShape.X = 12;
        mtShape.Y = 12;

        mtShape.CopyShapeState(activeShape);
        if( IsFirstTextQuillNull == null )
            mtShape.TextState.D[ mtShape.TextState.CurrentId ]._QuillDeltas = null ;
        
 
        mtShape.virtualSelected = true; 
        MyShapesState.Public_SetShapeState(mtShape.Id , mtShape);
        MyShapesState.Public_ClearAllSelectedShapes();
        MyShapesState.Public_SelectShape($("#" + Props.MultiTextImageCopyId));
        HideControlsMenu();

         // add menu

        var menu_str = "" , i ;
        for( i = 0 ; i < mtShape.TextState.D.length ; i++ )
        {
             
            // menu_str += "<li class='active'><span class='sprite-sbt sprite-sbt-Stretch'>&nbsp;&nbsp;&nbsp;</span>Text Area "+j+"</li>";
            var j = i + 1;
            menu_str += "<li>\
                    <a id='multitextable_textarea"+i+"' class='multitextable_textareacls' selid='"+i+"'>\
                        <span class='sprite-sbt sprite-sbt-Bring-Forward'>\
                        </span>\
                        <img height='16' width='16' src='/content/menu/blank.gif'>\
                        Text Area "+j+"\
                    </a>\
        </li>";
        } 
        GetGlobalById('MultiTextable-menu-select-id').innerHTML = menu_str;

        // menu select event
        $( ".multitextable_textareacls" ).click( function(){
            var j = this.getAttribute("selid") * 1 + 1;
            var i;
            $("#MultiTextable-header-title").html("Text Area "  + j);
            for( i = 0 ; i < mtShape.TextState.D.length ; i++ )
            {
                var id = Props.MultiTextImageCopyId + "_TextBoxArea" + i;
                if( j - 1 == i)
                     $("#"+id).attr("style","stroke-dasharray:1,1; stroke: black; stroke-width: 0.5; ");
                else $("#"+id).attr("style","");
            }
            mtShape.TextState.CurrentId =  this.getAttribute("selid");
            MainControls.TextControls.PrepTextControls(MyPointers.Controls_TextableControls, 150, 140, mtShape);
        });

        var CurrentIdStr = (mtShape.TextState.CurrentId + 1);

        $("#MultiTextable-header-title").html("Text Area "  + CurrentIdStr );


        // detach control box and attach it to dialog
        $("#textableControls").removeClass("ControlsBox");
        var txtcontrol = $("#textableControls").detach();
        $("#MultiTextable-content").append(txtcontrol);
        
        for( i = 0 ; i < mtShape.TextState.D.length ; i++ )
            clone.find( '#' + Props.OriginalShape.Id + "_TextBoxArea" + i ).attr("id" ,Props.MultiTextImageCopyId + "_TextBoxArea" + i );
        $("#"+Props.MultiTextImageCopyId + "_TextBoxArea" + mtShape.TextState.CurrentId).attr("style","stroke-dasharray:1,1; stroke: black; stroke-width: 0.5; ");

        mtShape.UpdateDrawing(true);
        clone.find("[id$='selection_box'], [id$='_defs']").hide();
        MainControls.TextControls.PrepTextControls(MyPointers.Controls_TextableControls, 150, 140, mtShape);

         $('#MultiTextableModal').on('hidden.bs.modal', function () {
            MyShapesState.Public_RemoveShapeStateById(Props.MultiTextImageCopyId);
        })
      
    }

    function PrepareShapePostModalClosure(activeShape)
    {
        return function (e)
        {  
            PrepareShapePostModal( activeShape);
        };
    };

    MultiTextableObject.ShowMultipleDialog = function( activeShape )
    {
        MyPointers.Dialog_MultiTextable.one('shown.bs.modal', PrepareShapePostModalClosure(activeShape));
        
        //prevent showing the previous crop
        var multiTextableSvg = $("#multiTextableSvg");
        multiTextableSvg.children().remove();

        MyPointers.Dialog_MultiTextable.modal();
    };

    MultiTextableObject.Cancel = function( )
    { 
        MyPointers.Dialog_MultiTextable.modal('hide');
    };

    MultiTextableObject.Update = function( )
    { 
        // copy result text  
        Props.OriginalShape.CopyTextState(mtShape.TextState);
        Props.OriginalShape.UpdateDrawing(true);
        MyPointers.Dialog_MultiTextable.modal('hide');
    };

    

    return MultiTextableObject;

}();