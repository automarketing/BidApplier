﻿ShapeActionEnum = {
    Nothing: "Nothing",
    Selected: "Selected",
    SelectedControlsHidden: "Selected twice",
    Move: "moving",
    Resize: "Resizing",
    Rotating: "Rotating",
    MultiSelecting: "MultiSelecting"
};