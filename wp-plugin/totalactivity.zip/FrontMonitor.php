<?php
function getBrowser() {

    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];

    $browser        =   "Unknown Browser";

    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/edge/i'       =>  'Edge',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );

    foreach ($browser_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }

    }

    return $browser;

}

function getOS() {

    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];

    $os_platform    =   "Unknown OS Platform";

    $os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}


function detectDevice(){

	$userAgent = $_SERVER["HTTP_USER_AGENT"];
	$devicesTypes = array(
        "computer" => array("msie 10", "msie 9", "msie 8", "windows.*firefox", "windows.*chrome", "x11.*chrome", "x11.*firefox", "macintosh.*chrome", "macintosh.*firefox", "opera"),
        "tablet"   => array("tablet", "android", "ipad", "tablet.*firefox"),
        "mobile"   => array("mobile ", "android.*mobile", "iphone", "ipod", "opera mobi", "opera mini"),
        "bot"      => array("googlebot", "mediapartners-google", "adsbot-google", "duckduckbot", "msnbot", "bingbot", "ask", "facebook", "yahoo", "addthis")
    );
 	foreach($devicesTypes as $deviceType => $devices) {           
        foreach($devices as $device) {
            if(preg_match("/" . $device . "/i", $userAgent)) {
                $deviceName = $deviceType;
            }
        }
    }
    return ucfirst($deviceName);
 }


function wpse_20160114_update_plugin() {


    global $wpdb;

    // don't run on ajax calls
    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
        return;
    }
 
    $exc = array('png','jpg','.js', 'bmp' , 'csv', 'pdf' , 'css' );
    $thr = strtolower(substr($_SERVER['REQUEST_URI'], -3));
    if( in_array($thr , $exc) ) return;
 
    $result = $wpdb->get_results( "select value from wp_useracitivity_opt where option='fpattern'", 'ARRAY_A' );
 
    foreach ($result as $item) 
    	 if( strpos( $_SERVER['REQUEST_URI'] , $item['value']) ) 
	{ 
	 	return;
	}

    // Main installation of database    

    $result = $wpdb->get_results( "SHOW TABLES LIKE 'wp_useractivity'", 'ARRAY_A' );
    if( count($result) == 0 )
    {
    	    $wpdb->query("CREATE TABLE  `wp_useractivity` ( 
				`UID` INT(10) NOT NULL AUTO_INCREMENT , 
				`IP` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`DNS` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL , 
				`Page` VARCHAR(90) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`Device` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`OS` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`time` VARCHAR(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`Country` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`Region` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`City` VARCHAR(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`Company` VARCHAR(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`Tel` VARCHAR(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`email` VARCHAR(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL ,
				`duration` int(10) NOT NULL,
					PRIMARY KEY (`UID`)) ENGINE = InnoDB;");

    	    $wpdb->query("CREATE TABLE `wp_useracitivity_opt` (                  
	        `UID` int(10) unsigned NOT NULL AUTO_INCREMENT,      
	        `option` varchar(15) COLLATE utf8_bin DEFAULT NULL,  
	        `value` varchar(20) COLLATE utf8_bin DEFAULT NULL,   
	        PRIMARY KEY (`UID`)                                  
	      ) ENGINE = InnoDB; ");

    	    $wpdb->insert( "wp_useracitivity_opt" , array( "option" => "keep_period" , "value"=>'5' ) );
    	    $wpdb->insert( "wp_useracitivity_opt" , array( "option" => "keep_period" , "value"=>'5' ) );
    }

    if( is_admin() ) {
        return;
    }

    // Fetch user information
  
	if( $_SERVER['REMOTE_ADDR'] == '::1' ) 
		$_SERVER['REMOTE_ADDR'] = 'localhost';
	$ip = $_SERVER['REMOTE_ADDR']; 
 
	if( filter_var($ip, FILTER_VALIDATE_IP) )
	{
		$dns = gethostbyaddr($ip);
		if( strpos($dns, 'bot') !== false ) return;

		// connect to db
		$servername = "talendexpertdotcom.cgghnjpb0mia.eu-west-1.rds.amazonaws.com";
		$username = "talendexpertdb";
		$password = "ALondon20144";
		$dbname = "talendexpertdotcom";

		//fetch out ip information from 3rd database

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
		}
		$ip_val= sprintf('%u', ip2long($ip));

		$sql = "SELECT * FROM ipligence2 where ip_from <=".$ip_val." and ".$ip_val."<= ip_to";
 
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
		    // output data of each row
		    while($row = $result->fetch_assoc()) {
		        $country = $row["country_name"];
		        $region = $row["region_name"];
		        $city = $row["city_name"];
		        $company = $row["owner"];
		        break;
		    }
		} else {
		}
		$conn->close();
	}

	$wp_arr = array( 'IP' => $ip  ,  'DNS' => $dns ,
	'Page' => $_SERVER['REQUEST_URI'] , 'time' => date("Y-m-d H:i:s") , 'Device' => detectDevice(), 'OS' => getOS()."<br>".getBrowser()  ,
	'Country'=> isset($country) ? $country : '' , 'City'=>isset($city) ? $city : '' , 'Region'=> isset(     $Region ) ?  $Region : '' , 
	'Company' =>isset($company) ? $company : '' );

	$wpdb->insert( 'wp_useractivity', $wp_arr ) ;
	$lastid = $wpdb->insert_id;


?> 
	<script type='text/javascript'>

	jQuery(document).ready(function($) 
	{

		var startTime = new Date();
<?php	 

		 $link = admin_url('admin-ajax.php') ;
		 echo "var ajaxurl = '$link'";
?>		
 
		function update_duration(){
			var endTime = new Date();
		        var timeDiff = endTime - startTime + 1000;
			timeDiff /= 1000;

		        $.ajax({
			          method: "POST",
			          url: ajaxurl,
			          data: { 'action': 'dobsondev_ajax_total_activity_update_duration', 
					  	  'uid': '<?php echo $lastid; ?>',
						  'duration' : timeDiff ,
				  }

			})
			.done(function( data ) 
		        {
			 	console.log(data);
			 	setTimeout(update_duration, 5000);
		        });
		}

		update_duration();
		
	});
        
        </script>
 
<?php
}

add_action('wp_footer', 'wpse_20160114_update_plugin');


?>