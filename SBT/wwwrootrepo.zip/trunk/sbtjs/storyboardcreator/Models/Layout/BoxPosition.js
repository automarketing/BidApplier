﻿function BoxPosition(height, width, x, y, row, col, storyboardPartType)
{
    this.Height = height;
    this.Width = width;
    this.X = x;
    this.Y = y;

    //Optional!
    this.Row = row;
    this.Col = col;
    this.StoryboardPartType = storyboardPartType;
}