<?php
/*
Plugin Name: User activity
Plugin URI: http://Sqinfotech.com
Description: User activity report
Version: 1.0
Author: pDos
Author URI:  http://Sqinfotech.com
*/ 

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

// Detect device type , computer , tablet , mobile or bot
require_once('BackMainTab.php');
require_once('FrontMonitor.php');
require_once('BackMain.php');
require_once('BackMostActiveCompany.php');
require_once('BackMostVisitedPage.php');




// css attachment

function wpse_load_plugin_css() {
    $plugin_url = plugin_dir_url( __FILE__ );

    wp_enqueue_style( 'style', $plugin_url . 'totalactivity.css' ); 
}
add_action( 'admin_enqueue_scripts', 'wpse_load_plugin_css' );


register_deactivation_hook( __FILE__, 'my_plugin_remove_database' );

function my_plugin_remove_database() 
{
     global $wpdb;
     $tblList = array('useractivity' , 'useracitivity_opt' , 'useractivity2');

     for( $i = 0 ; $i < count($tblList) ; $i++ )
     {     	
	     $table_name = $wpdb->prefix .$tblList[$i];
	     $sql = "DROP TABLE IF EXISTS $table_name";
	     $wpdb->query($sql); 
    }
}



require_once('BackCompany.php');