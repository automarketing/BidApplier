﻿var OpacitySliderOldValue = null;
var OpacityHelper = function (){
    var OpacityHelperObject = new Object();
    
    OpacityHelperObject.initControls= function()
    {
        var slider = $('#opacity-slider').slider({
            value: 1,
            formater: function (value)
            {
                return parseInt (value) + "%";
            }
        }); 

        $('#opacity-slider').on( 'slide', handleOpacitySlide );
        $('#opacity-slider').on( 'slideStart', handleOpacitySlideStart );
        $('#opacity-slider').on( 'slideStop', handleOpacitySlideStop );
        $("#opacity-slider").data("previousValue", 1);
    }

    function handleOpacitySlideStart()
    {
        OpacitySliderOldValue = $('#opacity-slider').data("previousValue");
        handleOpacitySlide();
    }
    
    function handleOpacitySlide()
    {
        var activeShape = MyShapesState.Public_GetFirstSelectedShapeState();
        if( activeShape.IsTextable() )
            return;

        var newVal = $('#opacity-slider').slider('getValue');
        OpacityHelper.setOpacity( activeShape , newVal );
        return newVal;

    }

    function handleOpacitySlideStop()
    {
        var activeShape = MyShapesState.Public_GetFirstSelectedShapeState();
        if( activeShape.IsTextable() )
            return;

        var newVal = handleOpacitySlide();
        UndoManager.register(undefined, OpacityHelper.setOpacity, [ activeShape , OpacitySliderOldValue], undefined, '', OpacityHelper.setOpacity, [activeShape,newVal]);
    }

    OpacityHelperObject.setOpacity = function ( shape , val ){
        if( shape.IsTextable() )
            return;
        shape.opacity = val/100.0;
        UpdateActiveDrawing();
    }


    OpacityHelperObject.setSliderValue = function(val)
    {
        $('#opacity-slider').slider('setValue', val);
        $("#opacity-slider").data("previousValue", val);
    }
    return OpacityHelperObject;
}();