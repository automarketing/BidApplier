﻿function SpiderCellLocation(title, fakeCol, fakeRow, rowOffset)
{
    this.Title = title;
    this.FakeCol = fakeCol;
    this.FakeRow = fakeRow;
    this.RowOffset = rowOffset;
}

