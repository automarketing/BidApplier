﻿/// <reference path="../svgManip.js" />


function MathUtilsLibrary()
{

};

MathUtilsLibrary.prototype.CartesianSegmentLength = function (startPoint, endPoint) {
    var a = endPoint.X - startPoint.X;
    var b = endPoint.Y - startPoint.Y;
    return Math.sqrt((a * a) + (b * b));
};